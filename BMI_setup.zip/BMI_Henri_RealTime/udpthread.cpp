#include "udpthread.h"
#include "gui.h"
#include "sockets.h"





UDPThread::UDPThread(QObject *parent) :
    QObject(parent)
{
    WSAData wsaData;
    WSAStartup(MAKEWORD(2, 2), &wsaData); // Load Winsocks2


    sckt = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP); //Create the socket

    if (sckt == SOCKET_ERROR)
        {
            std::cout << "Creation socket Error : " << Sockets::GetError() << std::endl;
        }

    sockaddr_in addr;
    addr.sin_addr.s_addr = INADDR_ANY; // Listen to every local interface
    addr.sin_port = htons(51002); // translate port into network endianess
    addr.sin_family = AF_INET; // Ipv4 adress



    if (bind(sckt, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) != 0) //Bind the Socket
    {
        std::cout << "Bind socket Error : "<< Sockets::GetError() << std::endl;
    }



    // If the While 1 loop starts immediatly, it does not give the time to the gui to load.
    UDPTimer = new QTimer(this);
    UDPTimer->setSingleShot(true);
    UDPTimer->connect(UDPTimer,SIGNAL(timeout()),this,SLOT(UDPcallback()));
    UDPTimer->start();
    t.start();





}



void UDPThread::UDPcallback(){
    //    int timey=0;
    //    int diff =0;
    //    int loss=0;
    //    int plus=0;
    //    float tot=0;

    while (1)
    {

        char buff[1500] = {};

        sockaddr_in from;
        socklen_t fromlen=sizeof(from);


        int ret = recvfrom(sckt, buff,1500,0, reinterpret_cast<sockaddr*>(&from), &fromlen); // Receive data from the port buffer

        if (ret <= 0)
        {
            std::cout << "Error, not receiving data : " << Sockets::GetError() << ". Close program.";
            break;
        }


        for (int k=0; k<1490 ;k++) //Loop through all bytes of the buffer
        {
            // Check if one Byte corresponds to a channel number
            if (UINT32 (buff[k])<33 && (UINT32 (buff[k])>0)){


                // Here we check if the channel number we found is in a spike packet or not
                /// SPIKE PACKET STRUCTURE
                /// Bytes 1,2,3,4 : Timestamp
                /// Byte 5 : Channel (buff[k]) (0<Chan<33) =====> First condition checked (for most non-spike packets, channel = 0)
                /// Byte 6 : 0 (buff[k+1])
                /// Byte 7 : Unit number (buff[k+2]) (0<Unit<6)
                /// Byte 8 : dlen = 28
                /// Bytes 9 = 0

                if (UINT32 (buff[k+1]) ==0 && UINT32 (buff[k+2]) > 0 &&  UINT32 (buff[k+2])<6  &&  UINT32 (buff[k+3])==28 && UINT32 (buff[k+4])==0 && UINT32 (buff[k+8])==0 && UINT32 (buff[k+12])==0){
                    QPair<int,int> chanU = qMakePair(UINT32 (buff[k]),UINT32 (buff[k+2]));
//                    UINT32 Timestamp = UINT32(((unsigned char)(buff[k-4])) |
//                                        ((unsigned char)(buff[k-3])) << 8 |
//                                        ((unsigned char)(buff[k-2])) << 16 |
//                                        ((unsigned char)(buff[k-1]))<< 24);
                    //std::cout<<"spike packet : channel = "<<UINT32 (buff[k])<<" unit = "<<UINT32 (buff[k+2])<< " Time = "<< Timestamp <<std::endl;

//                    if (UINT32 (buff[k+2]!=1)){
//                        qDebug()<<"spike packet";
//                        for (int j =-2;j<50;j++){
//                            qDebug()<<uint(buff[k+j]);
//                        }



//                    }


                    if (ListChanUPos.contains(chanU)){
                        UDPSpkListpos.append(t.elapsed());



                    }
                    if (ListChanUNeg.contains(chanU)){
                        UDPSpkListneg.append(t.elapsed());


                    }

                    ////                  TO COMPUTE PACKET LOSS AND GAIN
                    //                    std::cout<<"channel = "<< UINT32 (buff[k])<< " Unit = "<< UINT32 (buff[k+2])<< std::endl;
                    //                    diff= t.elapsed()-timey;
                    //                    qDebug()<<diff;
                    //                    if (diff>17){
                    //                        loss++;
                    //                        tot++;
                    //                    }
                    //                    if (diff<14 && t.elapsed()>20){
                    //                        plus+=1;
                    //                    }
                    //                    tot++;
                    //                    timey=t.elapsed();
                    //                    std::cout<<"udpread ratio loss : "<<float(loss)/tot<<std::endl;
                    //                    std::cout<<"udpread ratio gain : "<<float(plus)/tot<<std::endl;
                }
            }

            // Check if one Byte corresponds to the dlen value of a DINP packet (code to detect lick, the logic is a bit weird here
            if (uint (unsigned char(buff[k]))==36){

                // Here we check if the channel number we found is in a DINP packet or not
                /// LICK PACKET STRUCTURE
                /// Bytes 1,2,3,4 : Timestamp
                /// Byte 5 : Channel (buff[k-3]) = 0
                /// Byte 6 : = 4294967168 (buff[k-2])
                /// Byte 7 : = 99 (buff[k-1]) (0<Unit<6)
                /// Byte 8 : dlen (buff[k]) = 36
                /// Bytes 9,10 : 0
                /// Length then can change. However it is sure that after around 45 bytes, there are quite a few of 0 bytes (buff(k+60:k+65))
                /// Also, before this, a rising edge lick detection ends by 53/10/0/..../0. thus the second for loop

                if (UINT32 (buff[k-3])==0 && UINT32 (buff[k-2])==4294967168 && UINT32 (buff[k-1])==99 &&UINT32 (buff[k+1])==0 &&UINT32 (buff[k+2])==0 &&UINT32 (buff[k+60])==0 &&UINT32 (buff[k+61])==0 &&UINT32 (buff[k+62])==0&&UINT32 (buff[k+63])==0 &&UINT32 (buff[k+64])==0 &&UINT32 (buff[k+65])==0){
                    for (int l = 30;l<60;l++){
                        if(UINT32 (buff[k+l])==0&&UINT32 (buff[k+l+1])==0&&UINT32 (buff[k+l+2])==0&&UINT32 (buff[k+l-2])==53&&UINT32 (buff[k+l-3])==51)
                        {
                            Lick.store(1);
                            LickCounter++;

                        }
                    }
                }
            }
        }


    }
}



