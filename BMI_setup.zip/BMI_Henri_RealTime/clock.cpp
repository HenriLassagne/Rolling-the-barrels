#include "clock.h"

Clock::Clock():
QGraphicsScene()
{
    setSceneRect(-110, -110,220, 220);
    QPen penJoint(Qt::black, 8, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin);
    QPen penCercle(Qt::black, 2, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin);
    QPen penRewardArc(Qt::green, 1, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin);
    QPen penPunishArc(Qt::red, 0.1, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin);

    Joint = this->addLine(QLine(0, 0, 0, 100), penJoint);
    RewardArc = this->addEllipse(-105,-105,210,210,penRewardArc);

    PunishArc = this->addEllipse(-105,-105,210,210,penPunishArc);


    Cercle = this->addEllipse(-105,-105,210,210,penCercle);
    Joint->setZValue(3);


}

Clock::~Clock()
{
}


void Clock::update(){
Joint->setRotation(qreal(360-FrameIdx.load()));
}

void Clock::switch_off(){
    Joint->setOpacity(0.3);
}

void Clock::switch_on(){
    Joint->setOpacity(1);

}


void Clock::init(){

    RewardArc->setStartAngle((RewardLowerThd.load()-90)*16);
    RewardArc->setSpanAngle((RewardUpperThd.load()-RewardLowerThd.load())*16);
    RewardArc->setBrush(QColor::fromRgbF(0,1,0,0.7));

    PunishArc->setStartAngle(((RewardUpperThd.load()+RewardLowerThd.load())/2+(180-NoLick.load())/2)*16);
    PunishArc->setSpanAngle(NoLick.load()*16);
    PunishArc->setBrush(QColor::fromRgbF(1,0,0,0.7));



}

