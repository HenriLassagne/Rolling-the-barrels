#include "gui.h"


class Chart *chart;
QChartView *m_chartView;

class Clock *clock1;
QGraphicsView *m_clockView;

QMutex paramMut;
QString refImageFolder;

//Parameters of the Session
QString DataFolder; // Folder "Data", Parametre
QAtomicInteger<unsigned int> Mouse; // mouse number
QAtomicInteger<unsigned int> Session; // session number
QAtomicInteger<unsigned int> LatencyToAdd; // mouse number
QAtomicInteger<unsigned int> RewardLowerThd; // Lower reward boundary
QAtomicInteger<unsigned int> RewardUpperThd; // Upper reward boundary
QAtomicInteger<unsigned int> NoLick; // Width of the no lick zone in degrees
QAtomicInteger<unsigned int> Water; // 0: controled by algo; 1: free reward; 2: flush
QAtomicInteger<unsigned int> RandomizedActive;
QFile File; //File which contains the groups of units
QStringList PlaybackFrameList;
QStringList PlaybackFrameCurrent;

Protocole param; //Protocol of the session

QList <QPair<int,int>> ListChanUPos; // List of pairs chan/unit in the positive group
QList <QPair<int,int>> ListChanUNeg; // Same for the negative group

QTime t;
int gain;
float frot;



QAtomicInteger<int> GrabReferenceImage; // To tell the ccd camera thread when you grab a reference image

//Flags and Timers
QAtomicInteger<unsigned int> WaitingActive; // 0: mean OFF; 1: mean ON
QAtomicInteger<unsigned int> SessionActive; // 0: mean OFF; 1: mean ON; 2: mean JUST STARTED; 3 mean PLAYBACK
QAtomicInteger<unsigned int> DefineGroupsActive; // 0: mean OFF; 1: mean ON; 2: mean JUST STARTED
QAtomicInteger<unsigned int> LatencyActive; // 0: mean OFF; 1: mean ON; 2 mean Just STARTED

QTimer *WaitingTimer; //Timer for the waiting period
QTimer *SessionTimer; //Timer for the session
QTimer *DefineGroupsTimer; //Timer for the Define Groups session
QTimer *LatencyTimer;

//In Session Variables
QAtomicInteger<unsigned int> SpkCountpos; // spiking count pos in time window
QAtomicInteger<unsigned int> SpkCountneg; // spiking count neg in time window

QList<unsigned int> UDPSpkListpos;
QList<unsigned int> UDPSpkListneg;
QAtomicInteger<unsigned int> Lick;


QAtomicInteger<unsigned int> fmaxpos;// Frequence maximale, groupe pos atteinte pendant la WP
QAtomicInteger<unsigned int> fmaxneg; // Frequence maximale, groupe neg atteinte pendant la WP
QAtomicInteger<unsigned int> LastLick; // Lick yet to be processed
QAtomicInteger<unsigned int> LastReward; // Reward yet to be processed
QAtomicInteger<unsigned int> FrameIdx; // Index of the current frame, to keep both displays up to date
QAtomicInteger<int> RewardCounter; // To count the number of rewards and display on the GUI
QAtomicInteger<int> RewardCounterTrial=0; // To count the number of rewards in a single trial
QAtomicInteger<int> TrialCounter = 1; //To count the trials
QAtomicInteger<int> LickCounter; // To count the licks
QAtomicInteger<unsigned int> WaitingPRD; // waiting period in minutes for calculating the baseline activity.
QAtomicInteger<unsigned int> SessionPRD; // total duration of one session in minutes
QAtomicInteger<unsigned int> RoutineTime; // variable holding the routine call value
QAtomicInteger<unsigned int> CurrentPBTrial; // random trial in the playback database
QAtomicInteger<unsigned int> PBframenumber; // number of the PB frame displayed
QAtomicInteger<int> NLickforReward;

//For The Define Group session

QList<QList<QAtomicInteger<unsigned int>>>TblSpkCount;

QList<QAtomicInteger<unsigned int>> SpkCountTetrode1;
QList<QAtomicInteger<unsigned int>> SpkCountTetrode2;
QList<QAtomicInteger<unsigned int>> SpkCountTetrode3;
QList<QAtomicInteger<unsigned int>> SpkCountTetrode4;
QList<QAtomicInteger<unsigned int>> SpkCountTetrode5;
QList<QAtomicInteger<unsigned int>> SpkCountTetrode6;
QList<QAtomicInteger<unsigned int>> SpkCountTetrode7;
QList<QAtomicInteger<unsigned int>> SpkCountTetrode8;

QList<QAtomicInteger<unsigned int>> AllActiveSpkCounts;
QList<QAtomicInteger<unsigned int>> AllActiveTetrodes;
QList<QAtomicInteger<unsigned int>> AllActiveUnits;

//List of Units, Positive and negatice groups
QList<QAtomicInteger<unsigned int>> SpkCountsPos;
QList<QAtomicInteger<unsigned int>> TetrodesPos;
QList<QAtomicInteger<unsigned int>> UnitsPos;

QList<QAtomicInteger<unsigned int>> SpkCountsNeg;
QList<QAtomicInteger<unsigned int>> TetrodesNeg;
QList<QAtomicInteger<unsigned int>> UnitsNeg;





float PreviousPosition; //Previous position of the joint (= Previous Frame)
float CurrentPosition; //Current position (= Current Frame)
float PreviousSpeed;
float CurrentSpeed;
float CurrentAcceleration;
float DropSize; // size of water droplet as reward in µL

int waterAOUT;
int lickDIN;
int maxSpkCount;
int binsizeFR;


int main(int argc, char *argv[])
{
    srand(time(0));
    QApplication a(argc, argv);
    Gui w;
    w.show();

    return a.exec();
}
