#include "gui.h"


Protocole::Protocole()
{
    /// INIT AN ACTUAL PROTOCOLE
    /// From ini file, get file name, reward parameter, and time outs
    QString IniFile = DataFolder + "/Protocoles/Latency_protocol.ini";
    QSettings settings(IniFile, QSettings::IniFormat);
    QString currentStimulusFileName = settings.value("Frames").toString();
    rewardStrength = settings.value("RewardStrength").toDouble();
    timeOut = settings.value("timeOut").toDouble();
    brightness = settings.value("brightness").toFloat();
    rewardLower = settings.value("RewardLower").toInt();
    rewardUpper = settings.value("RewardUpper").toInt();
    NoLickRange = settings.value("NoLickRange").toInt();
    NLicksforReward = settings.value("NLicksForReward").toInt();


    /// number of patterns and number of frame per pattern
    nPatterns = settings.value("nPatterns").toInt();
    nFrames = settings.value("nFrames").toLongLong();
    frameDuration = settings.value("frameDuration").toLongLong(); // duration during which a single frame is displayed
    frameIllumination = settings.value("frameIllumination").toLongLong(); // duration during which a single frame is illuminated

    /// Load the patterns
    ///==================
    QString imageFolder = DataFolder + "/mouse" + QString::number(Mouse.load()) + "/Frames/" + currentStimulusFileName + "/";

    QImage image;

    // names are numbers from 0 to N for the pattern, an underline, then a second number for the frame number.
    // the parameter file contains the pattern count and frame count
    // names


    for (int i = 0; i<nPatterns+1; i++)
    {
        QList<QImage> FramesSinglePattern = {};

        for (int j = 0; j<nFrames; j++)
        {
            QString imageFile = imageFolder + QString::number(i) + "_" + QString::number(j) + ".tiff";
            QFileInfo check_file(imageFile);
            if (check_file.exists())
            {
                image.load(imageFile);
            }
            else
            {
                qDebug() << "File doesn't exist";
            }
            FramesSinglePattern.append(image);
        }

        /// Add the patterns in a frame list to be displayed over the projector
        FrameList.append(FramesSinglePattern);

    }

}
