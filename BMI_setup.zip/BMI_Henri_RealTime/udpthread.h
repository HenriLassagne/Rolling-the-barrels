#ifndef UDPTHREAD_H
#define UDPTHREAD_H

#include "gui.h"

class UDPThread : public QObject
{
    Q_OBJECT

public:
    explicit UDPThread(QObject *parent = 0);


    SOCKET sckt;
    QTimer *UDPTimer;
public Q_SLOTS:
    void UDPcallback();






};

#endif // UDPTHREAD_H
