#include "gui.h"
#include "spkandbehav.h"


std::default_random_engine generator;
std::exponential_distribution<double> update_target(2000);
std::uniform_real_distribution<double> sin_amp;
std::uniform_real_distribution<double> sin_phase;
std::uniform_real_distribution<double> sin_freq;

//Statics
QList<unsigned int> SpkAndBehav::LickList;
QList<unsigned int> SpkAndBehav::SpkListpos;
QList<unsigned int> SpkAndBehav::SpkListneg;

//Local Variables
int SpkAndBehav::risingEdgeLick = 0;

///#############################################################################################
/// Constructeur
/// #############################################################################################

SpkAndBehav::SpkAndBehav(QObject *parent) :
    QObject(parent)
{

    /// Connection to Blackrock !

    cbSdkConnection con;
    cbSdkConnectionType conType = CBSDKCONNECTION_UDP;
    res = cbSdkOpen(0, conType, con);


    /// Define Units to be recorded
    cbSdkSetComment(0,0,0,("Unit=" + QString::number(6)).toStdString().c_str());

    /// Set digital in for the licking input
    LickHist = 0;


    currentWaterAOUT = waterAOUT; // Parametre

    /// Initialisation des Timers

    RoutineTimer = new QTimer(this);
    RoutineTimer->setInterval(RoutineTime); // in milliseconds, Parametre
    RoutineTimer->setTimerType(Qt::PreciseTimer);
    RoutineTimer->start();
    RewardTimer= new QTimer(this);
    RewardTimer->setTimerType(Qt::PreciseTimer);
    QObject::connect(RewardTimer, SIGNAL(timeout()),this, SLOT(reset_trial()));
    remaintime=4000;
    RewardTimer->setInterval(remaintime);
    TrialTimer = new QTimer(this);
    TrialTimer->setInterval(20000);
    TrialTimer->setTimerType(Qt::PreciseTimer);
    QObject::connect(TrialTimer, SIGNAL(timeout()),this, SLOT(reset_trial()));

    Frame_counter=0;
    QObject::connect(RoutineTimer, SIGNAL(timeout()), this, SLOT(routine()));
    rewardtrig=0;

    /// Register the callback !
    res = cbSdkRegisterCallback(0, CBSDKCALLBACK_LOG, LogCallback, 0);

    /// Initialisation de la punition (white noise)
    player = new QMediaPlayer;
    player->setMedia((QUrl::fromLocalFile("C:/Users/User/Desktop/white_noise.wav")));
    player->setVolume(100);



}

void SpkAndBehav::closeProgram()
{
    /// Disconnect the perpetual call to the routine
    QObject::disconnect(RoutineTimer, SIGNAL(timeout()), this, SLOT(routine()));
    /// Unregister the callback
    res = cbSdkUnRegisterCallback(0, CBSDKCALLBACK_LOG);

}

///#############################################################################################
/// CallBack, Recover all the NSP's packets for Session Active (runs in parallel for some reasons, but is not used anymore except for chart)
/// ############################################################################################
void SpkAndBehav::LogCallback(UINT32, const cbSdkPktType type, const void* pEventData, void*)
{
    char *nPos;
    int nTime;
    int nChan;
    int nUnit;
    int nDigValue;

    switch(type)
    {
    case cbSdkPkt_LOG:
        if (pEventData)
        {
            cbPKT_LOG pLog = *reinterpret_cast<const cbPKT_LOG *>(pEventData);
            // initialize values
            nTime = nChan = nUnit = nDigValue = 0;
            // get the timestamp
            nPos = strstr(pLog.desc, "T:");
            if (nPos)
                nTime = atoi(&nPos[2]);
            // check for digital entry
            nPos = strstr(pLog.desc, "D:");
            if (nPos)
                nDigValue = atoi(&nPos[2]);
            // check for channel
            nPos = strstr(pLog.desc, "C:");
            if (nPos)
                nChan = atoi(&nPos[2]);
            // check for unit
            nPos = strstr(pLog.desc, "U:");
            if (nPos)
                nUnit = atoi(&nPos[2]);

            if (nChan){
                // Make pair chan/Unit
                QPair<int,int> chanU = qMakePair(nChan,nUnit);


                if (ListChanUPos.contains(chanU)){
                    SpkListpos.append(nTime);
                }
                if (ListChanUNeg.contains(chanU)){
                    SpkListneg.append(nTime);

                }
            }
            else{
                // Get lick activity in a QList
                if (risingEdgeLick == 0){ // Catch only rising edge of digital events.
                    LickList.append(nTime);

                    risingEdgeLick = 1;
                } else {
                    risingEdgeLick = 0;

                }
            }
        }
        break;
    default:
        break;
    }
    return;
}

///#############################################################################################
/// CallBack, Recover all the NSP's packets for each channel (Choose groups condition) still used
/// ############################################################################################
void SpkAndBehav::LogCallback2(UINT32, const cbSdkPktType type, const void* pEventData, void*)
{
    char *nPos;
    int nTime;
    int nChan;
    int nUnit;
    int nDigValue;

    switch(type)
    {
    case cbSdkPkt_LOG:
        if (pEventData)
        {
            cbPKT_LOG pLog = *reinterpret_cast<const cbPKT_LOG *>(pEventData);
            // initialize values
            nTime = nChan = nUnit = nDigValue = 0;
            // get the timestamp
            nPos = strstr(pLog.desc, "T:");
            if (nPos)
                nTime = atoi(&nPos[2]);
            // check for digital entry
            nPos = strstr(pLog.desc, "D:");
            if (nPos)
                nDigValue = atoi(&nPos[2]);
            // check for channel
            nPos = strstr(pLog.desc, "C:");
            if (nPos)
                nChan = atoi(&nPos[2]);
            // check for unit
            nPos = strstr(pLog.desc, "U:");
            if (nPos)
                nUnit = atoi(&nPos[2]);

            if (nChan){
                if (nUnit !=0){
                    if(nChan==7 || nChan==8 || nChan==9 || nChan==10 ){
                        SpkCountTetrode1[nUnit-1]+=1;
                    }
                    if(nChan==1 || nChan==2 || nChan==13 || nChan==14 ){
                        SpkCountTetrode2[nUnit-1]+=1;
                    }
                    if(nChan==19 || nChan==20 || nChan==31 || nChan==32 ){
                        SpkCountTetrode3[nUnit-1]+=1;
                    }
                    if(nChan==23 || nChan==24 || nChan==25 || nChan==26 ){
                        SpkCountTetrode4[nUnit-1]+=1;
                    }
                    if(nChan==4 || nChan==6 || nChan==11 || nChan==12 ){
                        SpkCountTetrode5[nUnit-1]+=1;
                    }
                    if(nChan==3 || nChan==5 || nChan==15 || nChan==16 ){
                        SpkCountTetrode6[nUnit-1]+=1;
                    }
                    if(nChan==17 || nChan==18 || nChan==27 || nChan==29 ){
                        SpkCountTetrode7[nUnit-1]+=1;
                    }
                    if(nChan==21 || nChan==22 || nChan==28 || nChan==30 ){
                        SpkCountTetrode8[nUnit-1]+=1;
                    }

                }
            }
        }
        break;
    default:
        break;
    }
    return;
}

///#############################################################################################
/// ROUTINE
/// ############################################################################################
void SpkAndBehav::routine(){

    /// Get current NSP time
    res = cbSdkGetTime(0, &CurrentTime);

    ///#############################################################################################
    /// Compute the Frequencies of each group, previous way, using the callback and BR timestamps
    /// ############################################################################################

    /// Frequence du groupe positif
//    while (SpkListpos.count()> 2000) //Parametre (2000 spk)
//    {
//        SpkListpos.removeFirst();
//    }
//    young_spk_count = 0;

//    for (int i = (SpkListpos.count()-1); i>=0 ; i--)
//    {
//        if (static_cast<int>(CurrentTime - SpkListpos[i]) > (binsizeFR+LatencyToAdd)*(30000/1000)) // Sampling rate = 30000 Hz
//        { // too old, stop counting
//            break;
//        }
//        if (static_cast<int>(CurrentTime-SpkListpos[i]) > LatencyToAdd*(30000/1000)) // Henri,  implemented, way to introduce a delay (shift the window)
//        {
//            young_spk_count += 1;
//        }
//    }
//    SpkCountpos.store(young_spk_count);

//    /// Frequence du groupe négatif
//    while (SpkListneg.count()> 2000) //Parametre (2000 spk)
//    {
//        SpkListneg.removeFirst();
//    }
//    young_spk_count = 0;

//    for (int i = (SpkListneg.count()-1); i>=0 ; i--)
//    {
//        if (static_cast<int>(CurrentTime - SpkListneg[i]) > (binsizeFR+LatencyToAdd)*(30000/1000)) // Sampling rate = 30000 Hz
//        { // too old, stop counting
//            break;
//        }
//        if (static_cast<int>(CurrentTime-SpkListneg[i]) > LatencyToAdd*(30000/1000)) // Henri,  implemented, way to introduce a delay (shift the window)
//        {
//            young_spk_count += 1;
//        }
//    }
//    SpkCountneg.store(young_spk_count);

    ///#############################################################################################
    /// Compute instant Frequencies of each group + add latencies. New way, with UDP Paquets
    /// ############################################################################################

    while (UDPSpkListpos.count()> 2000) //Parametre (2000 spk)
    {
        UDPSpkListpos.removeFirst();
    }
    young_spk_count = 0;

    for (int i = (UDPSpkListpos.count()-1); i>=0 ; i--)
    {
        if (static_cast<int>(t.elapsed()  - UDPSpkListpos[i]) > (binsizeFR+LatencyToAdd)) // Sampling rate = 30000 Hz
        { // too old, stop counting
            break;
        }
        if (static_cast<int>(t.elapsed()  - UDPSpkListpos[i]) > LatencyToAdd) // Henri,  implemented, way to introduce a delay (shift the window)
        {
            young_spk_count += 1;
            UDPSpkListpos.removeAt(i);
        }
    }
    SpkCountpos.store(young_spk_count);

    /// Frequence du groupe négatif
    while (UDPSpkListneg.count()> 2000) //Parametre (2000 spk)
    {
        UDPSpkListneg.removeFirst();
    }
    young_spk_count = 0;

    for (int i = (UDPSpkListneg.count()-1); i>=0 ; i--)
    {
        if (static_cast<int>(t.elapsed()  - UDPSpkListneg[i]) > (binsizeFR+LatencyToAdd)) // Sampling rate = 30000 Hz
        { // too old, stop counting
            break;
        }
        if (static_cast<int>(t.elapsed()  - UDPSpkListneg[i]) > LatencyToAdd) // Henri,  implemented, way to introduce a delay (shift the window)
        {
            young_spk_count += 1;
            UDPSpkListneg.removeAt(i);
        }
    }
    SpkCountneg.store(young_spk_count);


    ///#############################################################################################
    /// Waiting Period loop, recover the total number of spikes for each group
    /// ############################################################################################


    if (WaitingActive.load()==1){
        fmaxpos.store(fmaxpos.load()+SpkCountpos);
        fmaxneg.store(fmaxneg.load()+SpkCountneg);
    }


    ///#############################################################################################
    /// To define the groups of units
    /// ############################################################################################

    if (DefineGroupsActive.load()==2){
        res = cbSdkUnRegisterCallback(0, CBSDKCALLBACK_LOG);

        // Initialise the Spkcounts on each tetrode
        for (int k=0;k<5;k++){
        SpkCountTetrode1.append(0);
        SpkCountTetrode2.append(0);
        SpkCountTetrode3.append(0);
        SpkCountTetrode4.append(0);
        SpkCountTetrode5.append(0);
        SpkCountTetrode6.append(0);
        SpkCountTetrode7.append(0);
        SpkCountTetrode8.append(0);
        }

        res = cbSdkRegisterCallback(0, CBSDKCALLBACK_LOG, LogCallback2, 0);
        DefineGroupsActive.store(1);

    }


    ///#############################################################################################
    /// To test the latency
    /// ############################################################################################


    if (LatencyActive==2){
        fmaxpos.store(1);
        fmaxneg.store(1);
        initSession();
        ListChanUPos.append(qMakePair(20,1));
        ListChanUPos.append(qMakePair(18,1));
        ListChanUPos.append(qMakePair(22,1));
        ListChanUPos.append(qMakePair(24,1));
        LatencyActive.store(1);
    }





    ///#############################################################################################
    /// Initialisation if session starts
    /// ############################################################################################

    if (SessionActive.load()==2){
        initSession();
        SessionActive.store(1);
        reset_trial();
    }

    if (SessionActive.load()==4){
        initSession();
        SessionActive.store(3);
    }


    ///#############################################################################################
    /// Lick Activity (not used, except for chart)
    /// ############################################################################################

    if (LickList.count()>0) //if chid is 151 the lick are correctly read then this condition is satisfied
    {
        int OldLickTime = LickList[0];
        while (static_cast<int>(CurrentTime - OldLickTime) > (RoutineTime*(30000/1000))) // Licks should be updated at the same pace as routine. Parametre (10ms)
        {
            LickList.removeFirst();
            if (!LickList.isEmpty())
            {
                OldLickTime = LickList[0];
            }
            else
            {
                break;
            }
        }
        LastLick.store(LickList.last());
    }
    else
    {
        LastLick.store(0);
    }

    ///#############################################################################################
    /// Command Algorythm, Compute velocity and position
    /// ############################################################################################
    ///

    /// VELOCITY COMMAND MAX 100°/s
//        if (fmaxpos!=0 && fmaxneg !=0){
//            CurrentSpeed=(float(100)*SpkCountpos/fmaxpos.load()-float(100)*SpkCountneg/fmaxneg.load()); // Compute current speed of the virtual joint
//            CurrentPosition = PreviousPosition + float(RoutineTime)/1000*CurrentSpeed; // Deduce current postion Parametre

//            if (CurrentPosition>=360){
//                CurrentPosition = CurrentPosition-360; //Modulo 360
//            }
//            if (CurrentPosition<=0){
//                CurrentPosition = CurrentPosition + 360; // Modulo 360
//            }
//            PreviousPosition = CurrentPosition;
//            qDebug()<< CurrentPosition;
//        }


    /// ACCELERATION COMMAND
    ///

    gain=40000;
    frot=1.05;


    if (fmaxpos!=0 && fmaxneg !=0){
        CurrentAcceleration=float(gain)*(SpkCountpos*float((fmaxneg.load()))/(fmaxpos.load()+fmaxneg.load())-SpkCountneg*float((fmaxpos.load()))/(fmaxpos.load()+fmaxneg.load())); // Compute current Accelaration of the virtual joint

        CurrentSpeed = PreviousSpeed/frot + float(RoutineTime)/1000*CurrentAcceleration; // Deduce current postion Parametre (routine, coefficient amortissement)
        CurrentPosition = (PreviousPosition + float(RoutineTime)/1000*CurrentSpeed);

        if (CurrentPosition>=360){
            CurrentPosition = CurrentPosition-360; //Modulo 360
        }
        if (CurrentPosition<0){
            CurrentPosition = CurrentPosition + 360; // Modulo 360
        }
        PreviousSpeed = CurrentSpeed;
        PreviousPosition = CurrentPosition;



    }




    ///#############################################################################################
    /// Session Period loop
    /// ############################################################################################

    if (SessionActive.load()==1 || SessionActive.load()==3){
        ///Display the right frame !

        if (SessionActive.load()==1){ //Normal Condition
            FrameIdx.store(int(CurrentPosition));
            if (Frame_counter%10==0)
                cbSdkSetComment(0, 0, 0, ("F:" + QString::number(FrameIdx)).toStdString().c_str());
        }

        if (SessionActive.load()==3){ //PlayBack Condition

            if (int(PBframenumber.load())<PlaybackFrameCurrent.count()-1){
                QString a= PlaybackFrameCurrent[PBframenumber.load()];
                bool ok;
                quint64 no = a.toLong(&ok,10);
                CurrentPosition=no;

                if ((int(CurrentPosition) > int(RewardLowerThd.load())) && (int(CurrentPosition) < int(RewardUpperThd.load()))){
                    if ((FrameIdx <= RewardLowerThd.load()) ||  (FrameIdx >= RewardUpperThd.load()))
                    {
                        cbSdkSetComment(0, 0, 0, ("Entering Reward"));
                    }
                }

                FrameIdx.store(int(CurrentPosition));
                cbSdkSetComment(0, 0, 0, ("F:" + QString::number(FrameIdx)).toStdString().c_str());
                PBframenumber.store(PBframenumber+1);
            }

            else{
                qDebug()<<"Trial Timeout";
                reset_trial();
                Lick.store(0);
            }

        }

        Frame_counter++;



        if(RandomizedActive.load()==0){
            AlpProjStart(nDevId, nSeqId_list[FrameIdx]);
            }

        /// Deliver the Reward

        if ((FrameIdx >= RewardLowerThd.load()) && (FrameIdx <= RewardUpperThd.load()))
        {
            if (rewardtrig==0){    
                if (SessionActive.load()==1){
                    TrialTimer->setInterval(TrialTimer->remainingTime()+4000);
                    TrialTimer->start();
                    rewardtrig=1;
                    RewardTimer->setSingleShot(true);
                    RewardTimer->start(remaintime);
                }

            }

            if (Lick.load()==1 && Water.load() == 0) {

                if(RewardCounterTrial % NLickforReward ==0){

                    one_waterReward(); // Deliver one water reward
                    RewardCounter.store(RewardCounter.load() + 1); // Store total number of rewards
                }

                LastReward.store(1);

                RewardCounterTrial.store(RewardCounterTrial.load() + 1);


            }
            LickHist = LastLick.load();

        }
        else{
            if (rewardtrig==1){
                remaintime=RewardTimer->remainingTime();
                RewardTimer->stop();
                rewardtrig=0;
            }

        }



        /// Punishment
        ///
        int middle=(RewardLowerThd.load()+RewardUpperThd.load())/2;


        if ((int(FrameIdx)<middle-(360-NoLick.load())/2)  || (int(FrameIdx)>middle+(360-NoLick.load())/2)){
            if (Lick.load()==1 && Water.load() == 0) {
                if (SessionActive==1){
                    player->play();
                }
                qDebug()<<"Lick Timeout";
                reset_trial();
                }
            }

        if(RandomizedActive.load()==1){
            change_frame();
            AlpProjStart(nDevId, nSeqId_list[FrameIdx]);
            }


    }

    /// Water flow activation/stop
    if ((Water.load() == 1) && !(WaterBefore == 1))
    {
        WaterBefore = Water.load();
        continuous_waterReward();
    }
    if ((Water.load() == 0) && !(WaterBefore == 0))
    {
        WaterBefore = Water.load();
        stop_water();
    }
    if ((Water.load() == 2) && !(WaterBefore == 2))
    {
        WaterBefore = Water.load();
        start_flush();
    }
    if (Water.load() == 3)
    {
        res = cbSdkSetComment(0, 0, 0, "OneFreeReward");
        onefree_waterReward();
        Water.store(0);
        WaterBefore = Water.load();
    }

    if (LatencyActive==1){

        if (SpkCountpos.load()!=0){
            AlpProjStart(nDevId, nSeqId_list[360]);
            SpkCountpos.store(0);
        }

        if (Lick.load()==1){
            AlpProjStart(nDevId, nSeqId_list[360]);
        }


    }
    // Reinitialise the UDP Lick
    Lick.store(0);

}

void SpkAndBehav::reset_trial(){


    clock1->switch_off();
    int restart=0;
    FrameIdx.store(restart);

    if (SessionActive==1){
        TrialCounter++;

        remaintime=4000;
        rewardtrig=0;  
        PreviousPosition=restart;
        CurrentPosition=restart;
        PreviousSpeed=0;
        Sleep(2000);
        player->stop();
        Sleep(3000);
        TrialTimer->setInterval(20000);
        TrialTimer->start();
        RewardCounterTrial.store(0);
        res = cbSdkSetComment(0, 0, 0, ("Trial:" + QString::number(TrialCounter)).toStdString().c_str());
        SpkCountpos.store(0);
        SpkCountneg.store(0);
        UDPSpkListpos.clear();
        UDPSpkListneg.clear();

    }
    if (SessionActive==3){ // Playback condition
        TrialCounter++;
        CurrentPosition=restart;
        PBframenumber.store(0);
        Sleep(5000);
        RewardCounterTrial.store(0);
        CurrentPBTrial++;

        if (CurrentPBTrial>=PlaybackFrameList.count()){

            CurrentPBTrial=CurrentPBTrial-PlaybackFrameList.count();
        }

        PlaybackFrameCurrent=PlaybackFrameList[CurrentPBTrial].split(",");
        remaintime=4000;
        rewardtrig=0;

        res = cbSdkSetComment(0, 0, 0, ("Trial:" + QString::number(TrialCounter)).toStdString().c_str());




    }
    clock1->switch_on();



}

void SpkAndBehav::initSession(){

    res = cbSdkSetComment(0, 0, 0, "Init session");

    /// Log as events the mouse, session
    res = cbSdkSetComment(0, 0, 0, ("Mouse:"+ QString::number(Mouse.load())).toLocal8Bit().constData());
    res = cbSdkSetComment(0, 0, 0, ("Session:"+ QString::number(Session.load())).toLocal8Bit().constData());

    /// Update the parameters that are used
    paramMut.lock();
    currentParam = param;
    paramMut.unlock();

    /// Load the Parameters
    rewardStrength = currentParam.rewardStrength;

    RewardLowerThd.store(currentParam.rewardLower);
    RewardUpperThd.store(currentParam.rewardUpper);
    NoLick.store(currentParam.NoLickRange);
    NLickforReward.store(currentParam.NLicksforReward);

    timeOut = currentParam.timeOut;
    brightness = currentParam.brightness;
    frameDuration = currentParam.frameDuration;
    frameIllumination = currentParam.frameIllumination;
    FrameList = currentParam.FrameList;




    /// Log as events some parameters
    cbSdkSetComment(0, 0, 0, ("brightness:" + QString::number(brightness)).toStdString().c_str());
    cbSdkSetComment(0, 0, 0, ("frameDuration:" + QString::number(frameDuration)).toStdString().c_str());
    cbSdkSetComment(0, 0, 0, ("frameIllumination:" + QString::number(frameIllumination)).toStdString().c_str());
    cbSdkSetComment(0, 0, 0, ("RewardUpper:" + QString::number(RewardUpperThd.load())).toStdString().c_str()) ;
    cbSdkSetComment(0, 0, 0, ("RewardLower:" + QString::number(RewardLowerThd.load())).toStdString().c_str()) ;




    /// start the projector
    /// in LUT mode
    const int seq_count = FrameList.count();
    const int frame_count = FrameList[0].count();
    nSeqId_list = QVector<ALP_ID>(seq_count);

    /// Allocate the ALP high-speed device
    if (ALP_OK != AlpDevAlloc( ALP_DEFAULT, ALP_DEFAULT, &nDevId )){
        qDebug() << "AlpDevAlloc failed. Check projector";
        return;
    }
    /// queue mode...
    if (ALP_OK != AlpProjControl(nDevId, ALP_PROJ_QUEUE_MODE, ALP_PROJ_SEQUENCE_QUEUE)){
        qDebug()<< "AlpProjControl failed. Check projector";
        return;
    }

    /// Allocate the sequences in FrameList (nPatterns parameter)
    for (int i = 0; i < seq_count ; i++) {
        /// init a sequence
        if (ALP_OK != AlpSeqAlloc( nDevId, 1, frame_count, &(nSeqId_list[i]))){
            qDebug() << "AlpSeqAlloc failed. Check projector";
            return;
        }
        /// Fill the buffer with the images
        for (int j = 0; j < frame_count; j++)
        {
            if(ALP_OK != AlpSeqPut( nDevId, nSeqId_list[i], j, 1, FrameList[i][j].bits())){
                qDebug() << "AlpSeqPut failed. Check projector";
                return;
            }
        }
        if (ALP_OK != AlpSeqTiming(nDevId, nSeqId_list[i],frameIllumination, frameDuration, ALP_DEFAULT, ALP_DEFAULT, ALP_DEFAULT)){
            qDebug()<< "AlpSeqTiming failed. Check projector";
            return;
        }
        if (ALP_OK != AlpSeqControl(nDevId, nSeqId_list[i],ALP_BITNUM,1)){
            qDebug() << "AlpSeqControl failed. Check projector";
            return;
        }
    }

    /// initialize LED
    AlpLedAlloc(nDevId, ALP_HLD_PT120TE_BLUE, NULL, &AlpLedId );
    AlpLedControl(nDevId, AlpLedId, ALP_LED_BRIGHTNESS, brightness);
    AlpLedControl(nDevId, AlpLedId, ALP_LED_SET_CURRENT, 30000);

    clock1->init();

}

void SpkAndBehav::one_waterReward(){


    /// if the water reward is continuous
    /// Set a waveform that will be played every time there is a reward
    /// duration of the phases of the waveform
    uint16_t wDur[2];
    wDur[0] = 1500; //at 30 000 Hz
    wDur[1] = 0; // 10 ms at 30 000 Hz, just to ensure that the pulse goes down after 10ms

    /// voltage of the phases of the waveform
    int16_t wAmp[2];
    wAmp[0] = 25000; // 3V TTL
    wAmp[1] = 0; // 0 V baseline

    /// Define the analog waveform
    cbSdkWaveformData wf;
    wf.type = cbSdkWaveform_PARAMETERS; // through the shape defined in the repeats parameter
    wf.repeats = 1; // one reward
    wf.trig = cbSdkWaveformTrigger_NONE; // Instant software trigger
    wf.trigChan = 0; // Channel trigger: not used here
    wf.trigValue = 0; // Channel trigger: not used here
    wf.trigNum = 0; // Channel trigger: not used here
    wf.offset = 0; // Channel trigger: not used here
    wf.duration = wDur; // duration of the phases of the waveform
    wf.amplitude = wAmp;// voltage over the phases of the waveform
    wf.phases = 2; // yet another way to set the number of repeats of the waveform

    res = cbSdkSetAnalogOutput(0, currentWaterAOUT, &wf, NULL);

    res = cbSdkSetComment(0, 0, 0, "OneWaterReward");
    //qDebug() << "Single water reward";

}

void SpkAndBehav::continuous_waterReward(){
    /// if the water reward is continuous
    // analog out channel for the reward
    //UINT16 channel = 146; //Analog output channel number on NSP (channel 2)
    /// Set a waveform that will be played every time there is a reward
    /// duration of the phases of the waveform
    uint16_t wDur[2];
    wDur[0] = 1000; // 20 ms at 30 000 Hz
    wDur[1] = 0; // 0 ms at 30 000 Hz, just to ensure that the pulse goes down after 10ms

    /// voltage of the phases of the waveform
    int16_t wAmp[2];
    wAmp[0] = 25000; // 3V TTL
    wAmp[1] = 0; // 0 V baseline

    /// Define the analog waveform
    cbSdkWaveformData wf;
    wf.type = cbSdkWaveform_PARAMETERS; // through the shape defined in the repeats parameter
    wf.repeats = 1; // continuous reward
    wf.trig = cbSdkWaveformTrigger_DINPREG;
    wf.trigChan = 2; // Channel trigger
    wf.trigValue = 0; // Channel trigger: not used here
    wf.trigNum = 0; // Channel trigger: not used here
    wf.offset = 0; // Channel trigger: not used here
    wf.duration = wDur; // duration of the phases of the waveform
    wf.amplitude = wAmp;// voltage over the phases of the waveform
    wf.phases = 2; // yet another way to set the number of repeats of the waveform

    res = cbSdkSetAnalogOutput(0, currentWaterAOUT, &wf, NULL);

}

void SpkAndBehav::onefree_waterReward(){
    /// Set a waveform that will be played every time there is a reward
    /// duration of the phases of the waveform
    uint16_t wDur[2];
    wDur[0] = 2000; // 250 ms at 30 000 Hz
    wDur[1] = 300; // 10 ms at 30 000 Hz, just to ensure that the puse goes down after 10ms

    /// voltage of the phases of the waveform
    int16_t wAmp[2];
    //wAmp[0] = 32767; // 5V TTL
    wAmp[0] = 25000; // 3V TTL
    wAmp[1] = 0; // 0 V baseline


    /// Define the analog waveform
    cbSdkWaveformData wf;
    wf.type = cbSdkWaveform_PARAMETERS; // through the shape defined in the repeats parameter
    wf.repeats = 1; // continuous reward
    wf.trig = cbSdkWaveformTrigger_NONE; // Instant software trigger
    wf.trigChan = 0; // Channel trigger: not used here
    wf.trigValue = 0; // Channel trigger: not used here
    wf.trigNum = 0; // Channel trigger: not used here
    wf.offset = 0; // Channel trigger: not used here
    wf.duration = wDur; // duration of the phases of the waveform
    wf.amplitude = wAmp;// voltage over the phases of the waveform
    wf.phases = 1; // yet another way to set the number of repeats of the waveform

    res = cbSdkSetAnalogOutput(0, currentWaterAOUT, &wf, NULL);

}

void SpkAndBehav::start_flush(){
    /// Set a waveform that will be played every time there is a reward
    /// duration of the phases of the waveform
    uint16_t wDur[2];
    wDur[0] = 7000; // 250 ms at 30 000 Hz
    wDur[1] = 300; // 10 ms at 30 000 Hz, just to ensure that the puse goes down after 10ms

    /// voltage of the phases of the waveform
    int16_t wAmp[2];
    wAmp[0] = 32767; // 5V TTL
    wAmp[0] = 25000; // 5V TTL
    wAmp[1] = 0; // 0 V baseline


    /// Define the analog waveform
    cbSdkWaveformData wf;
    wf.type = cbSdkWaveform_PARAMETERS; // through the shape defined in the repeats parameter
    wf.repeats = 0; // continuous flushing
    wf.trig = cbSdkWaveformTrigger_NONE; // Instant software trigger
    wf.trigChan = 0; // Channel trigger: not used here
    wf.trigValue = 0; // Channel trigger: not used here
    wf.trigNum = 0; // Channel trigger: not used here
    wf.offset = 0; // Channel trigger: not used here
    wf.duration = wDur; // duration of the phases of the waveform
    wf.amplitude = wAmp;// voltage over the phases of the waveform
    wf.phases = 1; // yet another way to set the number of repeats of the waveform

    res = cbSdkSetAnalogOutput(0, currentWaterAOUT, &wf, NULL);

}

void SpkAndBehav::stop_water(){
    /// Set a waveform that will be played every time there is a reward
    /// duration of the phases of the waveform
    uint16_t wDur[1];
    wDur[0] = 300; // 10 ms at 30 000 Hz. Constantly ON

    /// voltage of the phases of the waveform
    int16_t wAmp[2];
    wAmp[0] = 0; // 5V TTL

    /// Define the analog waveform
    cbSdkWaveformData wf;
    wf.type = cbSdkWaveform_PARAMETERS; // through the shape defined in the repeats parameter
    wf.repeats = 10; // continuous reward
    wf.trig = cbSdkWaveformTrigger_NONE; // Instant software trigger
    wf.trigChan = 0; // Channel trigger: not used here
    wf.trigValue = 0; // Channel trigger: not used here
    wf.trigNum = 0; // Channel trigger: not used here
    wf.offset = 0; // Channel trigger: not used here
    wf.duration = wDur; // duration of the phases of the waveform
    wf.amplitude = wAmp;// voltage over the phases of the waveform
    wf.phases = 1; // yet another way to set the number of repeats of the waveform

    res = cbSdkSetAnalogOutput(0, currentWaterAOUT, &wf, NULL);
}

void SpkAndBehav::change_frame(){
    QList<int> LUT={0,7,8,1,2,5,6,9,10,3,4,11};
    int q=FrameIdx.load()/30;
    int r=FrameIdx.load()%30;
    FrameIdx.store(30*LUT[q]+r);







}
