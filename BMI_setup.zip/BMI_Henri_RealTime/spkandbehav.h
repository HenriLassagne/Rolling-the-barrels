#ifndef SPKANDBEHAV_H
#define SPKANDBEHAV_H

#include "gui.h"
#include "cbsdk.h"
#include "alp.h"
#include "protocole.h"
#include "winsock.h"


class SpkAndBehav : public QObject
{
    Q_OBJECT

public:
    explicit SpkAndBehav(QObject *parent = 0);
    static void LogCallback(UINT32, const cbSdkPktType type, const void* pEventData, void*); //Recuperer les event de Blackrock !
    static void LogCallback2(UINT32, const cbSdkPktType type, const void* pEventData, void*); //Recuperer les event de Blackrock !
    static QList<unsigned int> LickList;
    static QList<unsigned int> SpkListpos;
    static QList<unsigned int> SpkListneg;
    static int risingEdgeLick;




private:
    // Blackrock/Projector
    cbSdkResult res;
    ALP_ID nDevId, AlpLedId;
    QVector<ALP_ID> nSeqId_list;

    uint CurrentTime;
    uint Frame_counter;
    uint young_spk_count;

    uint rewardtrig; // =1 if in the rewarded area, else 0
    uint remaintime;

    //Timers
    QTimer *RoutineTimer;
    QTimer *RewardTimer; //4 cumulative seconds in the reward area before restart
    QTimer *TrialTimer; //reset every 20s
    QMediaPlayer *player;


    // Fonctions
    void closeProgram();
    void initSession();
    void one_waterReward();
    void continuous_waterReward();
    void onefree_waterReward();
    void start_flush();
    void stop_water();
    void change_frame();



    unsigned int frameDuration;
    unsigned int frameIllumination;
    unsigned int rewardStrength;
    unsigned int timeOut;
    long brightness;
    unsigned int LickHist;
    unsigned int WaterBefore;


    int currentWaterAOUT;

    QList<QList<QImage>> FrameList;

    Protocole currentParam;




public Q_SLOTS:
    void routine();
    void reset_trial();




};

#endif // SPKANDBEHAV_H
