#ifndef DEFINES_H
#define DEFINES_H

#define DEMO 0 // if 1 then a fake spiking rate is used, and the display is desactivated. If 0 the full program runs.

#endif // DEFINES_H
