#ifndef CLOCK_H
#define CLOCK_H

#include "gui.h"

class Clock : public QGraphicsScene
{
    Q_OBJECT

public:
    Clock();
    virtual ~Clock();
    void update();
    void init();
    void switch_on();
    void switch_off();

private:

    QGraphicsItem *Joint;
    QGraphicsItem *Cercle;
    QGraphicsEllipseItem *RewardArc;
    QGraphicsEllipseItem *PunishArc;
    QPen *penJoint;
    QPen *penCircle;
    QPen *penRewardArc;
    QPen *penPunishArc;
    QPainter* Painter;
    const QStyleOptionGraphicsItem* option;

};

#endif // CLOCK_H

