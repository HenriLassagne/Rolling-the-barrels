#ifndef PROTOCOLE_H
#define PROTOCOLE_H


#include "gui.h"


class Protocole
{
public:
    Protocole();

    QList<QList<QImage>> FrameList;

    double rewardLower;
    double rewardUpper;
    double rewardStrength;
    double timeOut;
    double brightness;
    double NoLickRange;
    double NLicksforReward;
    int nPatterns;
    int nFrames;
    int frameDuration; // duration during which a single frame is displayed
    int frameIllumination; //duration during which a single frame is illuminated
};

#endif // PROTOCOLE_H
