#ifndef GUI_H
#define GUI_H


/// Import WinSock2 Library. CAREFUL ! when importing windows.h, you automatically also import winsocks,
/// but we need Winsock2 so it creates a conflict (redefinition issues). define WINSOCK_API in gui.h to
/// prevent window.h to load winsocks


#define _WINSOCKAPI_


#include <QMediaPlayer>
#include <QtWidgets/QWidget>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QGroupBox>
#include <QDebug>
#include <QThread>
#include <QTimer>
#include <QApplication>
#include <QSettings>
#include <QMessageBox>
#include <random>
#include <tuple>
#include <iostream>
#include <QProcess>
#include <QTime>

#include <QGraphicsScene>
#include <QGraphicsItem>

#include <QtGui/QImage>
#include <QDir>
#include <QFile>
#include <QDateTime>
#include <QMutex>

#include <QtCharts/QChartGlobal>
#include <QtCharts/QChart>
#include <QtCharts/QChartView>
#include <QtCharts>

#include "spkandbehav.h"
#include "protocole.h"
#include "chart.h"
#include "clock.h"
#include "sockets.h"
#include "udpthread.h"


#include "time.h"
#include "alp.h"
#include "cbsdk.h"

#include <TCHAR.h>
#include "WinSock2.h"
#include <windows.h>
#include <conio.h>
#include "stdlib.h"
#include <stdint.h>
#include <stdio.h>
#include <ctime>
#include "livethread.h"




extern Protocole param;


extern class Chart *chart;
extern QChartView *m_chartView;

extern class Clock *clock1;
extern QGraphicsView *m_clockView;

extern QAtomicInteger<int> GrabReferenceImage;
// Description des externes dans le main
extern QString DataFolder;
extern QFile File;
extern QStringList PlaybackFrameList;
extern QStringList PlaybackFrameCurrent;
extern QAtomicInteger<unsigned int> PBframenumber;

extern QMutex paramMut;
extern QAtomicInteger<unsigned int> Mouse;
extern QAtomicInteger<unsigned int> Session;
extern QAtomicInteger<unsigned int> LatencyToAdd;
extern QAtomicInteger<unsigned int> WaitingActive;
extern QAtomicInteger<unsigned int> SessionActive;
extern QAtomicInteger<unsigned int> DefineGroupsActive;
extern QAtomicInteger<unsigned int> LatencyActive;
extern QAtomicInteger<unsigned int> SpkCountpos;
extern QAtomicInteger<unsigned int> SpkCountneg;
extern QAtomicInteger<unsigned int> fmaxpos;
extern QAtomicInteger<unsigned int> fmaxneg;
extern QAtomicInteger<unsigned int> RewardLowerThd;
extern QAtomicInteger<unsigned int> RewardUpperThd;
extern QAtomicInteger<unsigned int> NoLick;
extern QAtomicInteger<unsigned int> Water;
extern QAtomicInteger<unsigned int> CurrentPBTrial;
extern QAtomicInteger<int> NLickforReward;
extern QAtomicInteger<unsigned int> RandomizedActive;

extern QTimer *WaitingTimer;
extern QTimer *SessionTimer;
extern QTimer *DefineGroupsTimer;
extern QTimer *LatencyTimer;

extern QAtomicInteger<unsigned int> LastLick;
extern QAtomicInteger<unsigned int> LastReward;

extern QAtomicInteger<unsigned int> FrameIdx;
extern QAtomicInteger<int> RewardCounter;
extern QAtomicInteger<int> RewardCounterTrial;
extern QAtomicInteger<int> TrialCounter;
extern QAtomicInteger<int> LickCounter;
extern QAtomicInteger<unsigned int> WaitingPRD;
extern QAtomicInteger<unsigned int> SessionPRD;
extern QAtomicInteger<unsigned int> RoutineTime;

extern QList<QList<QAtomicInteger<unsigned int>>>TblSpkCount;
extern QList<QAtomicInteger<unsigned int>> SpkCountTetrode1;
extern QList<QAtomicInteger<unsigned int>> SpkCountTetrode2;
extern QList<QAtomicInteger<unsigned int>> SpkCountTetrode3;
extern QList<QAtomicInteger<unsigned int>> SpkCountTetrode4;
extern QList<QAtomicInteger<unsigned int>> SpkCountTetrode5;
extern QList<QAtomicInteger<unsigned int>> SpkCountTetrode6;
extern QList<QAtomicInteger<unsigned int>> SpkCountTetrode7;
extern QList<QAtomicInteger<unsigned int>> SpkCountTetrode8;


extern QList <QPair<int,int>> ListChanUPos; // List of pairs chan/unit in the positive group
extern QList <QPair<int,int>> ListChanUNeg;

extern QAtomicInteger<unsigned int> Lick;

extern QList<QAtomicInteger<unsigned int>> AllActiveSpkCounts;
extern QList<QAtomicInteger<unsigned int>> AllActiveTetrodes;
extern QList<QAtomicInteger<unsigned int>> AllActiveUnits;

extern QList<QAtomicInteger<unsigned int>> SpkCountsPos;
extern QList<QAtomicInteger<unsigned int>> TetrodesPos;
extern QList<QAtomicInteger<unsigned int>> UnitsPos;

extern QList<QAtomicInteger<unsigned int>> SpkCountsNeg;
extern QList<QAtomicInteger<unsigned int>> TetrodesNeg;
extern QList<QAtomicInteger<unsigned int>> UnitsNeg;

extern QList<unsigned int> UDPSpkListpos;
extern QList<unsigned int> UDPSpkListneg;
extern QList<unsigned int> LickList;

extern QTime t;


extern float PreviousPosition;
extern float CurrentPosition;
extern float PreviousSpeed;
extern float CurrentSpeed;
extern float CurrentAcceleration;
extern float DropSize;
extern float frot;

extern int waterAOUT;
extern int lickDIN;
extern int maxSpkCount;
extern int binsizeFR;
extern int gain;




class Gui : public QWidget
{
    Q_OBJECT

public:
    explicit Gui(QWidget *parent = 0);
    ~Gui();

    // Fonctions de récupération des données
    void ListMice(); //Liste de souris dans le dossier Data
    void GetLastSession(); //Recuperation de la dernière session

    void StartSession();


private:
    //projector
    ALP_ID nDevId, AlpLedId;

    // Widgets

    QComboBox *MouseComboBox;
    QComboBox *ProtocolComboBox;
    QDoubleSpinBox *m_abvDispSpinBox;

    QLabel *RewardCounterLabel;
    QLabel *LickCounterLabel;
    QLabel *TrialCounterLabel;
    QLabel *SessionCounterLabel;
    //QLabel *ImageLabel;
    QLabel *DateLabel;

    QPushButton *DefineGroupsButton;
    QPushButton *StartSessionButton;

    QPushButton *generatorButton;
    QProcess *generator; //Process to launch the python GUI
    QPushButton *ccd_cameraButton; // button to Start live
    QPushButton *ccd_grabRef;


    QPushButton *FreeRewardButton;
    QPushButton *ContinuousRewardButton;
    QPushButton *StartWaitingbutton;
    QPushButton *TestLatencyButton;
    QPushButton *StartPlaybackButton;
    QPushButton *FlushButton;

    QCheckBox *DefineGroupsCheckBox;
    QCheckBox *RandomizedCheckBox;

    //QImage *ProjectedFrameImage;

//    class Chart *chart;
//    QChartView *m_chartView;

//    class Clock *clock;
//    QGraphicsView *m_clockView;


    QTimer *DisplayTimer;



    // Layouts
    QHBoxLayout *HorizontalLayout;
    QHBoxLayout *HorizontalLayout2;
    QHBoxLayout *HorizontalLayout3;
    QHBoxLayout *HorizontalLayout4;

    QVBoxLayout *VerticalLayout;
    QVBoxLayout *VerticalLayout2;
    QVBoxLayout *VerticalLayout3;
    QVBoxLayout *VerticalLayout4;

    QFormLayout *ComboLayout;
    QFormLayout *ComboLayout2;

    QGroupBox *GroupBox;
    QGroupBox *GroupBox2;
    QGroupBox *GroupBox3;


    //Data Structures
    QList<int> mouseIDlist;
    QString currentSessionFileName;

    //thread that reads the spikes
    QThread *spkandbehavThread;
    class SpkAndBehav *spkandbehav;


    //UDP thread that reads the spikes
    QThread *ReadUDPThread;
    class UDPThread *Reader;

    // Live ccd camera thread
    QThread *thread;
    class LiveThread *worker;

    // NSP output init
    cbSdkResult res;

    // Local Protocole
    Protocole currentParam;




    void initWaiting(); // init the recordings, the files, etc
    void initLatency(); // same for latency test
    void initPlayback();
    void getGroups(); // recover the groups of units


public Q_SLOTS:
    void setMouse(); //Connection de la liste des souris
    void setLatency(); //Connection de la liste des protocoles
    void ActivateDefineUnits();
    void ActivateRandomized();

    void StartWaitingPeriod();
    void StopWaitingPeriod();

    void StartDefineGroups();
    void StopDefineGroups();

    void StartLatencyTest();
    void StopLatencyTest();

    void StartPlayback();
    void StopPlayback();

    void StopSession();
    void update_displays(); //update the Gui
    void updateUpperDisplay(double upper);

    void launch_ccd_camera(bool liveON);
    void launch_generator(bool generator_ON);
    void grab_image(bool);




    //Free Reward conditions
    void rewardON_OFF(bool reward_ON);
    void flushON_OFF(bool flush_ON);
    void oneFreeRewardON();


};

#endif // GUI_H
