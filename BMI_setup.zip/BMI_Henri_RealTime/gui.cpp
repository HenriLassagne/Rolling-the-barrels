#include "gui.h"
#include "clock.h"


Gui::Gui(QWidget *parent) :
    QWidget(parent)
{
    setFixedSize(600,600);
    /// LOAD THE PARAMETER FILE
    QString path = QApplication::applicationDirPath();




    /// From program ini file, get the data dir, the data
    QString IniFile = path + "/Parameters.ini";


    /// check if main parameter file exists and if yes: Is it really a file and no directory?
    QFileInfo check_inifile(IniFile);
    if (check_inifile.exists() && check_inifile.isFile()) {
        QSettings settings(IniFile, QSettings::IniFormat);
        DataFolder = settings.value("dataFolder").toString();
        waterAOUT = settings.value("waterAOUT").toInt();
        lickDIN = settings.value("lickDIN").toInt();
        maxSpkCount = settings.value("bufferSPIKECOUNT").toInt();
        binsizeFR = settings.value("binsizeFIRINGRATE(ms)").toInt();
        WaitingPRD = settings.value("waitingPeriod(min)").toInt();
        RoutineTime = settings.value("routineCall(ms)").toInt();
        SessionPRD = settings.value("sessionPeriod(min)").toInt();
        DropSize = settings.value("dropSize").toFloat();


    }
    else
    {
        QMessageBox msgBox;
        msgBox.setText("The main parameter file cannot be found.");
        msgBox.exec();
        QApplication::quit();
    }
    RewardCounter.store(0); // Init Reward counter


    ///#############################################################################################
    /// Definition and positioning of all Widgets
    /// #############################################################################################

    /// Definition


    MouseComboBox = new QComboBox(this);
    connect(MouseComboBox, SIGNAL(currentIndexChanged(int)), this, SLOT(setMouse()));

    ProtocolComboBox = new QComboBox(this);
    connect(ProtocolComboBox, SIGNAL(currentIndexChanged(int)), this, SLOT(setLatency()));

    m_abvDispSpinBox = new QDoubleSpinBox();
    m_abvDispSpinBox->setFixedSize(80,30);
    m_abvDispSpinBox->setMaximum(10000);
    m_abvDispSpinBox->setValue(5);
    m_abvDispSpinBox->setSingleStep(1);

    connect(m_abvDispSpinBox, SIGNAL(valueChanged(double)), this, SLOT(updateUpperDisplay(double)));

    RewardCounterLabel = new QLabel(this);
    RewardCounterLabel->setText(QString::number(RewardCounter.load()));

    LickCounterLabel = new QLabel(this);
    LickCounterLabel->setText(QString::number(RewardCounter.load()));

    TrialCounterLabel = new QLabel(this);
    TrialCounterLabel->setText(QString::number(TrialCounter.load()));


    SessionCounterLabel = new QLabel(this);

    DateLabel = new QLabel(this);
    DateLabel->setText(QDateTime::currentDateTime().toString());

    StartWaitingbutton = new QPushButton("Start Waiting");
    connect(StartWaitingbutton, SIGNAL(pressed()), this, SLOT(StartWaitingPeriod()));


    DefineGroupsButton = new QPushButton("Define Groups");
    DefineGroupsButton->setDisabled(true);
    connect(DefineGroupsButton,SIGNAL(clicked()),this,SLOT(StartDefineGroups()));

    TestLatencyButton = new QPushButton("Closed Loop Performance");
    connect(TestLatencyButton,SIGNAL(clicked()),this,SLOT(StartLatencyTest()));

    StartPlaybackButton = new QPushButton("Start Playback Session");
    connect(StartPlaybackButton,SIGNAL(clicked()),this,SLOT(StartPlayback()));


    StartSessionButton = new QPushButton("Start Session");
    StartSessionButton->setDisabled(true);



    /// Start CCD camera live
    ccd_cameraButton = new QPushButton("Go Live");
    ccd_cameraButton->setCheckable(true);
    connect(ccd_cameraButton, SIGNAL(toggled(bool)), this, SLOT(launch_ccd_camera(bool)));

    /// Grab a reference image from the CCD camera
    ccd_grabRef = new QPushButton("Grab Image");
    connect(ccd_grabRef, SIGNAL(clicked(bool)), this, SLOT(grab_image(bool)));

    /// Launch generator, a python app for generating and aligning stimuli
    generatorButton = new QPushButton("Launch generator");
    generatorButton->setCheckable(true);
    connect(generatorButton, SIGNAL(toggled(bool)), this, SLOT(launch_generator(bool)));



    FreeRewardButton = new QPushButton("Free Reward");
    connect(FreeRewardButton, SIGNAL(clicked()), this, SLOT(oneFreeRewardON()));

    ContinuousRewardButton = new QPushButton("Habituation");
    ContinuousRewardButton->setCheckable(true);
    connect(ContinuousRewardButton, SIGNAL(toggled(bool)), this, SLOT(rewardON_OFF(bool)));

    FlushButton = new QPushButton("Flush");
    FlushButton->setCheckable(true);
    connect(FlushButton, SIGNAL(toggled(bool)), this, SLOT(flushON_OFF(bool)));

    DefineGroupsCheckBox = new QCheckBox(this);
    connect(DefineGroupsCheckBox,SIGNAL(clicked()),this,SLOT(ActivateDefineUnits()));

    RandomizedCheckBox = new QCheckBox(this);
    connect(RandomizedCheckBox,SIGNAL(clicked()),this,SLOT(ActivateRandomized()));


    /// Chart
    chart = new Chart();
    chart->legend()->hide();
    m_chartView = new QChartView(chart);
    m_chartView -> setRenderHint(QPainter::Antialiasing);


    clock1 = new Clock();

    m_clockView = new QGraphicsView(clock1);
    m_clockView->setRenderHint(QPainter::Antialiasing);




    /// Positioning
    VerticalLayout2 = new QVBoxLayout(this);
    HorizontalLayout3 = new QHBoxLayout();
    VerticalLayout = new QVBoxLayout();


    ComboLayout = new QFormLayout();
    ComboLayout->setFormAlignment(Qt::AlignLeft);
    ComboLayout->setLabelAlignment(Qt::AlignLeft);
    ComboLayout->addRow("Mouse", MouseComboBox);
    ComboLayout->addRow("Protocole", ProtocolComboBox);
    ComboLayout->addRow("Session n°", SessionCounterLabel);
    ComboLayout->addRow("Date", DateLabel);
    ComboLayout->addRow("Define groups", DefineGroupsCheckBox);
    ComboLayout->addRow("Activate Randomized", RandomizedCheckBox);

    HorizontalLayout = new QHBoxLayout();

    HorizontalLayout->addWidget(StartWaitingbutton);
    HorizontalLayout->addWidget(DefineGroupsButton);
    HorizontalLayout->addWidget(StartSessionButton);


    ComboLayout2 = new QFormLayout();
    ComboLayout2->setFormAlignment(Qt::AlignLeft);
    ComboLayout2->setLabelAlignment(Qt::AlignLeft);
    ComboLayout2->addRow("Reward Counter",RewardCounterLabel);
    ComboLayout2->addRow("Trial n°",TrialCounterLabel);
    ComboLayout2->addRow("Lick n°",LickCounterLabel);

    HorizontalLayout4 = new QHBoxLayout();
    HorizontalLayout4->addWidget(ccd_cameraButton);
    HorizontalLayout4->addWidget(ccd_grabRef);
    HorizontalLayout4->addWidget(generatorButton);

    HorizontalLayout2 = new QHBoxLayout();
    HorizontalLayout2->addWidget(FreeRewardButton);
    HorizontalLayout2->addWidget(ContinuousRewardButton);
    HorizontalLayout2->addWidget(FlushButton);

    VerticalLayout->addLayout(ComboLayout);
    VerticalLayout->addLayout(HorizontalLayout);
    VerticalLayout->addWidget(TestLatencyButton);
    VerticalLayout->addWidget(StartPlaybackButton);
    VerticalLayout->addLayout(ComboLayout2);
    VerticalLayout->addLayout(HorizontalLayout4);
    VerticalLayout->addLayout(HorizontalLayout2);

    HorizontalLayout3->addLayout(VerticalLayout);
    //HorizontalLayout3->addWidget(ImageLabel);
    HorizontalLayout3->addWidget(m_clockView);

    VerticalLayout2->addLayout(HorizontalLayout3);
    VerticalLayout2->addWidget(m_abvDispSpinBox);
    VerticalLayout2->addWidget(m_chartView);



    ///#############################################################################################
    /// INIT GUI
    /// ############################################################################################

    /// Recover the list of mice



    ListMice();
    for (int i = 0; i< mouseIDlist.count(); i++){
        MouseComboBox->addItem(QString::number(mouseIDlist[i]), mouseIDlist[i]);
    }
    MouseComboBox->setCurrentIndex(-1); // start with empty combobox

    /// Init Thread for the camera
    thread = new QThread();
    worker = new LiveThread();


    /// Recover the list of protocoles
    ProtocolComboBox->addItem("Real Time");
    ProtocolComboBox->addItem("Physiology");
    ProtocolComboBox->addItem("Delayed");
    ProtocolComboBox->setCurrentIndex(-1);

    /// Init the thread that reads the spikes

    spkandbehavThread = new QThread();
    spkandbehav = new SpkAndBehav();
    spkandbehav->moveToThread(spkandbehavThread);
    spkandbehavThread->start();

    /// Init UDP Thread

    ReadUDPThread = new QThread();
    Reader = new UDPThread();
    Reader->moveToThread(ReadUDPThread);
    ReadUDPThread->start();





    /// Update the displays every 10ms
    DisplayTimer = new QTimer(this);
    connect(DisplayTimer, SIGNAL(timeout()), this, SLOT(update_displays()));
    DisplayTimer->setInterval(10);
    DisplayTimer->start();



}

Gui::~Gui()
{
//mystère et boule de gomme
}


///#############################################################################################
/// Récupération de la liste de souris !
/// ############################################################################################

void Gui::ListMice(){
    // List the mouse IDs in the data folder
    paramMut.lock();
    QDir root = QDir(DataFolder); // initialize the directory that will be parsed
    QStringList mouseNameList = root.entryList();
    QList<int> mouseIDs = QList<int>();
    // identify the mouse IDs
    for (int i = 0; i < mouseNameList.count(); i++){
        if ((mouseNameList[i].count() > 5) && (QString::compare(mouseNameList[i].left(5), QString("mouse"), Qt::CaseSensitive) == 0))
        {
            int numLength = mouseNameList[i].count() - 5; // extract the part of the string that contains the number
            QString IDstr = mouseNameList[i].right(numLength);
            mouseIDs.append(IDstr.toInt());
        }
    }
    std::sort(mouseIDs.begin(), mouseIDs.end());
    mouseIDlist = mouseIDs;

    /// From Units ini File, get the groups of units which will accelerate positively or negatively the joint


    paramMut.unlock();
}

///#############################################################################################
/// Stocker la valeur de la souris actuelle
/// #############################################################################################

void Gui::setMouse(){
    paramMut.lock();
    Mouse.store((unsigned int)(MouseComboBox->currentData().toInt()));
    GetLastSession();
    SessionCounterLabel->setText(QString::number(Session.load()+1));
    getGroups();
    paramMut.unlock();
}

///#############################################################################################
/// Stocker la valeur de la latence en fontion du protocole
/// #############################################################################################

void Gui::setLatency(){
    paramMut.lock();
    if (ProtocolComboBox->currentText()=="Real Time"){
        LatencyToAdd.store(0);
    }
    if (ProtocolComboBox->currentText()=="Physiology"){
        LatencyToAdd.store(46);
    }
    if (ProtocolComboBox->currentText()=="Delayed"){
        LatencyToAdd.store(196);
    }
    paramMut.unlock();
}

void Gui::updateUpperDisplay(double upper){
    chart->updateAbvDisplay(upper);
}

///#############################################################################################
/// Récupérer et stocker la valeur de la Dernière session
/// #############################################################################################


void Gui::GetLastSession(){

    // List the session numbers in the current mouse folder
    QDir root = QDir(DataFolder + "/mouse" + QString::number(Mouse.load()));
    QStringList sessionNameList = root.entryList();
    QList<unsigned int> sessionIDs = QList<unsigned int>();
    // identify the session IDs
    for (int i = 0; i < sessionNameList.count(); i++){
        QString IDstr;
        if (QString::compare(sessionNameList[i].left(7), "session") == 0)
        {
            int numLength = sessionNameList[i].count() - 7; // extract the part of the string that contains the number
            IDstr = sessionNameList[i].right(numLength);
        }
        sessionIDs.append((unsigned int)IDstr.toInt());
    }
    std::sort(sessionIDs.begin(), sessionIDs.end());
    Session.store(sessionIDs.last());
}

void Gui::StartDefineGroups(){
    paramMut.lock();
    DefineGroupsButton->setDisabled(true);
    param=Protocole();
    DefineGroupsTimer = new QTimer(this);

    DefineGroupsTimer->connect(DefineGroupsTimer,SIGNAL(timeout()),this,SLOT(StopDefineGroups()));
    DefineGroupsTimer->setInterval(WaitingPRD*60*1000); //Parametre
    DefineGroupsTimer->setTimerType(Qt::TimerType::PreciseTimer);
    DefineGroupsTimer->setSingleShot(true);
    DefineGroupsTimer->start();


    QString UnitsFolderName = DataFolder + "/mouse" + QString::number(Mouse.load()) + "/Units/";

    /// create folder that will contain the data
    QDir dir;
    dir.mkdir(UnitsFolderName);
    res = cbSdkSetComment(0, 0, 0, "Init choosing groups");

    DefineGroupsActive.store(2);


    paramMut.unlock();
}

void Gui::StopDefineGroups(){
    paramMut.lock();
    res = cbSdkUnRegisterCallback(0, CBSDKCALLBACK_LOG);
    DefineGroupsButton->setText("Done");
    DefineGroupsActive.store(0);

    TblSpkCount.append(SpkCountTetrode1);
    TblSpkCount.append(SpkCountTetrode2);
    TblSpkCount.append(SpkCountTetrode3);
    TblSpkCount.append(SpkCountTetrode4);
    TblSpkCount.append(SpkCountTetrode5);
    TblSpkCount.append(SpkCountTetrode6);
    TblSpkCount.append(SpkCountTetrode7);
    TblSpkCount.append(SpkCountTetrode8);

    QAtomicInteger<unsigned int> StrongSpkcount;
    QAtomicInteger<unsigned int> StrongUnit;
    QAtomicInteger<unsigned int> StrongTetrode;
    QAtomicInteger<unsigned int> Stop = 1;

    //Recover List of Active Unit (Spikecount, n°tetrode, n°Unit)
    while (Stop == 1)
    {
        for(int tetrode=0;tetrode<8;tetrode++){
            for(int Unit=0;Unit<5;Unit++){
                if (TblSpkCount[tetrode][Unit].load() > StrongSpkcount){
                    StrongSpkcount.store(TblSpkCount[tetrode][Unit].load());
                    StrongUnit.store(Unit);
                    StrongTetrode.store(tetrode);
                }
            }
        }
        TblSpkCount[StrongTetrode][StrongUnit].store(0);

        if (StrongSpkcount.load()==0){
            Stop.store(0);
        }
        if (StrongSpkcount.load()!=0){
            AllActiveSpkCounts.append(StrongSpkcount);
            AllActiveTetrodes.append(StrongTetrode);
            AllActiveUnits.append(StrongUnit);
            StrongSpkcount.store(0);
        }
    }

    //Greedy Algo

    for (int k=0; k<AllActiveSpkCounts.count();k++){
        if (std::accumulate(SpkCountsPos.begin(),SpkCountsPos.end(),0) <= std::accumulate(SpkCountsNeg.begin(),SpkCountsNeg.end(),0)){
            SpkCountsPos.append(AllActiveSpkCounts[k]);
            TetrodesPos.append(AllActiveTetrodes[k]+1); //Switch first index to 1 at this point
            UnitsPos.append(AllActiveUnits[k]+1);
        }
        else{
            SpkCountsNeg.append(AllActiveSpkCounts[k]);
            TetrodesNeg.append(AllActiveTetrodes[k]+1);
            UnitsNeg.append(AllActiveUnits[k]+1);
        }


    }

    QString fichier = DataFolder + "/mouse" + QString::number(Mouse.load()) + "/Units/groups.ini";

    QFile file(fichier); // Appel du constructeur de la classe QFile

    if (file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        // Si l'ouverture du fichier en écriture à réussie

        // ecrire dans le fichier

        file.write("Positive Group = ");
        for (int k = 0; k< SpkCountsPos.count();k++){

            QString pos = QString::number(TetrodesPos[k].load()) + QString::number(UnitsPos[k].load()) ;
            QByteArray bapos = pos.toLocal8Bit();
            const char *c_pos = bapos.data();
            file.write(c_pos);

        }
        file.write("\n");
        file.write("Negative Group = ");

        for (int k = 0; k< SpkCountsNeg.count();k++){

            QString neg = QString::number(TetrodesNeg[k].load()) + QString::number(UnitsNeg[k].load()) ;
            QByteArray baneg = neg.toLocal8Bit();
            const char *c_neg = baneg.data();
            file.write(c_neg);

        }
    }
    file.close();
    getGroups();


    paramMut.unlock();
}

void Gui::StartWaitingPeriod(){
    paramMut.lock();
    StartWaitingbutton->setDisabled(true);
    TestLatencyButton->setDisabled(true);
    StartPlaybackButton->setDisabled(true);
    param=Protocole();
    WaitingActive.store(1);
    WaitingTimer = new QTimer(this);
    WaitingTimer->connect(WaitingTimer,SIGNAL(timeout()),this,SLOT(StopWaitingPeriod()));
    WaitingTimer->setInterval(WaitingPRD*60*1000); //Parametre
    WaitingTimer->setTimerType(Qt::TimerType::PreciseTimer);
    WaitingTimer->setSingleShot(true);
    initWaiting();

    paramMut.unlock();

}

void Gui::initWaiting(){

    /// define the 30k continuous acquisition, no filter, of the data across all 32 channels
    cbPKT_CHANINFO chan_info;

    for (int i = 0; i < 32 ; i++){
        //get current channel configuration
        res = cbSdkGetChannelConfig(0, i+1, &chan_info);

        //change configuration
        chan_info.smpfilter = 0; //continuous filter (none)
        chan_info.smpgroup = 5; //continuous sampling rate (30kHz)

        //set channel configuration
        res = cbSdkSetChannelConfig(0, i+1, &chan_info); //note: channels start at 1
    }

    /// Configure the trial to include both continuous and event data
    uint16_t bActive = 1; // reset the trial
    uint16_t uBegChan   = 1;
    uint32_t uBegMask   = 0;
    uint32_t uBegVal    = 0;
    uint16_t uEndChan   = 32;
    uint32_t uEndMask   = 0;
    uint32_t uEndVal    = 0;
    bool   bDouble    = false;
    bool   bAbsolute  = false;
    uint32_t uWaveforms = 0;
    uint32_t uConts     = cbSdk_CONTINUOUS_DATA_SAMPLES; // record the continuous data
    uint32_t uEvents    = cbSdk_EVENT_DATA_SAMPLES;
    uint32_t uComments  = 1000; // should we record the comments ?
    uint32_t uTrackings = 0;
    res = cbSdkSetTrialConfig(0, bActive, uBegChan, uBegMask, uBegVal, uEndChan, uEndMask, uEndVal, bDouble, uWaveforms, uConts, uEvents, uComments, uTrackings, bAbsolute);

    /// Init the data recording: look at the next session number in the data folder of the current mouse
    /// create folder that will contain the data
    QString currentSessionFolderName = DataFolder + "/mouse" + QString::number(Mouse.load()) + "/session" + QString::number(Session.load()+1) + '/';

    /// create folder that will contain the data
    QDir dir;
    dir.mkdir(currentSessionFolderName);
    QString FileName = currentSessionFolderName + "data";

    /// Init the file.
    res = cbSdkSetFileConfig(0, FileName.toStdString().c_str(), "", true, cbFILECFG_OPT_NONE);

    /// Sleep for few seconds to allow the launch of recording dialogbox
    Sleep(1000);

    /// initiate the recording
    res = cbSdkSetComment(0, 0, 0, "Init waiting");
    WaitingTimer->start();

}

void Gui::StopWaitingPeriod(){
    WaitingActive.store(0);
    StartWaitingbutton->setText("Finished Waiting");
    cbSdkSetComment(0, 0, 0, "waiting ends");
    StartSession();

}

void Gui::StartSession(){
    paramMut.lock();
    StartSessionButton->setEnabled(true);
    StartSessionButton->setText("Stop Session");
    StartSessionButton->connect(StartSessionButton,SIGNAL(pressed()),this,SLOT(StopSession()));
    SessionTimer = new QTimer(this);
    SessionTimer->connect(SessionTimer,SIGNAL(timeout()),this,SLOT(StopSession()));
    SessionTimer->setSingleShot(true);
    SessionTimer->setInterval(SessionPRD*60*1000);//parametre
    SessionTimer->setTimerType(Qt::TimerType::PreciseTimer);
    cbSdkSetComment(0, 0, 0, ("FmaxP:" + QString::number(fmaxpos)).toStdString().c_str()) ;
    cbSdkSetComment(0, 0, 0, ("FmaxN:" + QString::number(fmaxneg)).toStdString().c_str()) ;
    cbSdkSetComment(0, 0, 0, ("Gain:" + QString::number(gain)).toStdString().c_str()) ;
    cbSdkSetComment(0, 0, 0, ("Frot:" + QString::number(frot)).toStdString().c_str()) ;
    cbSdkSetComment(0, 0, 0, ("Latency:" + QString::number(LatencyToAdd)).toStdString().c_str()) ;

    cbSdkSetComment(0, 0, 0, "Session starts");

    for (int i =0; i<ListChanUPos.count();i++)
    {
        cbSdkSetComment(0, 0, 0, ("Pos:" + QString::number(ListChanUPos[i].first)+ QString::number(ListChanUPos[i].second)).toStdString().c_str()) ;
    }
    for (int i =0; i<ListChanUNeg.count();i++)
    {
        cbSdkSetComment(0, 0, 0,("Neg:" + QString::number(ListChanUNeg[i].first) + QString::number(ListChanUNeg[i].second)).toStdString().c_str()) ;
    }

    SessionTimer->start();
    SessionActive.store(2);
    paramMut.unlock();


}

void Gui::StopSession(){



    SessionActive.store(0);
    SessionTimer->disconnect(SessionTimer,SIGNAL(timeout()),this,SLOT(StopSession()));
    StartSessionButton->setText("Start Session");
    StartSessionButton->setDisabled(true);

    res = cbSdkSetComment(0, 0, 0, ("Water(microL):" + QString::number(RewardCounter.load()*DropSize)).toStdString().c_str());

    /// close the recording file
    res = cbSdkSetFileConfig(0, currentSessionFileName.toStdString().c_str(), "", false, cbFILECFG_OPT_NONE);


    /// disconnect the CallBack
    res = cbSdkUnRegisterCallback(0, CBSDKCALLBACK_LOG);

    StartSessionButton->setText("Done");
    StartSessionButton->setDisabled(true);


    /// stop projector
    AlpDevHalt( nDevId );
    AlpDevFree( nDevId );
}

void Gui::StartLatencyTest(){
    paramMut.lock();

    DefineGroupsCheckBox->setDisabled(true);
    StartWaitingbutton->setDisabled(true);
    StartSessionButton->setText("Stop Session");
    TestLatencyButton->setDisabled(true);
    StartPlaybackButton->setDisabled(true);
    param=Protocole();
    LatencyActive.store(2);
    LatencyTimer = new QTimer(this);
    LatencyTimer->connect(LatencyTimer,SIGNAL(timeout()),this,SLOT(StopLatencyTest()));
    LatencyTimer->setInterval(5*60*1000);
    LatencyTimer->setTimerType(Qt::TimerType::PreciseTimer);
    LatencyTimer->setSingleShot(true);
    initLatency();
    paramMut.unlock();

}


void Gui::initLatency(){
    /// define the 30k continuous acquisition, no filter, of the data across all 32 channels
    cbPKT_CHANINFO chan_info;

    for (int i = 0; i < 40 ; i++){
        //get current channel configuration
        res = cbSdkGetChannelConfig(0, i+1, &chan_info);

        //change configuration
        chan_info.smpfilter = 0; //continuous filter (none)
        chan_info.smpgroup = 5; //continuous sampling rate (30kHz)

        //set channel configuration
        res = cbSdkSetChannelConfig(0, i+1, &chan_info); //note: channels start at 1
    }

    /// Configure the trial to include both continuous and event data
    uint16_t bActive = 1; // reset the trial
    uint16_t uBegChan   = 1;
    uint32_t uBegMask   = 0;
    uint32_t uBegVal    = 0;
    uint16_t uEndChan   = 32;
    uint32_t uEndMask   = 0;
    uint32_t uEndVal    = 0;
    bool   bDouble    = false;
    bool   bAbsolute  = false;
    uint32_t uWaveforms = 0;
    uint32_t uConts     = cbSdk_CONTINUOUS_DATA_SAMPLES; // record the continuous data
    uint32_t uEvents    = cbSdk_EVENT_DATA_SAMPLES;
    uint32_t uComments  = 1000; // should we record the comments ?
    uint32_t uTrackings = 0;
    res = cbSdkSetTrialConfig(0, bActive, uBegChan, uBegMask, uBegVal, uEndChan, uEndMask, uEndVal, bDouble, uWaveforms, uConts, uEvents, uComments, uTrackings, bAbsolute);

    /// Init the data recording: look at the next session number in the data folder of the current mouse
    /// create folder that will contain the data
    QString currentSessionFolderName = DataFolder + "/Latency" + "/session" + QString::number(Session.load()+1) + '/';

    /// create folder that will contain the data
    QDir dir;
    dir.mkdir(currentSessionFolderName);
    QString FileName = currentSessionFolderName + "data";

    /// Init the file.
    res = cbSdkSetFileConfig(0, FileName.toStdString().c_str(), "", true, cbFILECFG_OPT_NONE);

    /// Sleep for few seconds to allow the launch of recording dialogbox
    Sleep(1000);

    /// initiate the recording
    res = cbSdkSetComment(0, 0, 0, "Init waiting");
    LatencyTimer->start();


}

void Gui::StopLatencyTest(){
    LatencyActive.store(0);
    TestLatencyButton->setText("Done");

    /// close the recording file
    res = cbSdkSetFileConfig(0, currentSessionFileName.toStdString().c_str(), "", false, cbFILECFG_OPT_NONE);
    /// stop projector
    AlpDevHalt( nDevId );
    AlpDevFree( nDevId );

}

void Gui::StartPlayback(){
    paramMut.lock();
    param=Protocole();
    DefineGroupsCheckBox->setDisabled(true);
    StartSessionButton->setEnabled(true);
    StartWaitingbutton->setDisabled(true);
    TestLatencyButton->setDisabled(true);
    StartSessionButton->setText("Stop Session");
    StartPlaybackButton->setDisabled(true);
    StartSessionButton->connect(StartSessionButton,SIGNAL(pressed()),this,SLOT(StopPlayback()));
    SessionTimer = new QTimer(this);
    SessionTimer->connect(SessionTimer,SIGNAL(timeout()),this,SLOT(StopPlayback()));
    SessionTimer->setSingleShot(true);
    SessionTimer->setInterval(SessionPRD*60*1000);//parametre
    SessionTimer->setTimerType(Qt::TimerType::PreciseTimer);

    cbSdkSetComment(0, 0, 0, "Session starts");
    SessionTimer->start();
    initPlayback();

    paramMut.unlock();
    SessionActive.store(4);


}

void Gui::initPlayback(){
    /// Read the file
    ///

    QFile framefile = DataFolder + "/PlaybackSlow.txt";
    PBframenumber.store(0);
    framefile.open(QIODevice::ReadOnly);
    QString fr = framefile.readAll();

    PlaybackFrameList = fr.split("\n");

    /// Random Shuffle
    std::random_shuffle(PlaybackFrameList.begin(),PlaybackFrameList.end());
    CurrentPBTrial=0;


    // List the session numbers in the current mouse folder
    QDir root = QDir(DataFolder + "/mouse" + QString::number(Mouse.load()) +"/Playback/");
    QStringList sessionNameList = root.entryList();
    QList<unsigned int> sessionIDs = QList<unsigned int>();
    // identify the session IDs
    for (int i = 0; i < sessionNameList.count(); i++){
        QString IDstr;
        if (QString::compare(sessionNameList[i].left(7), "session") == 0)
        {
            int numLength = sessionNameList[i].count() - 7; // extract the part of the string that contains the number
            IDstr = sessionNameList[i].right(numLength);
        }
        sessionIDs.append((unsigned int)IDstr.toInt());
    }
    std::sort(sessionIDs.begin(), sessionIDs.end());

    int SessionPlayback;
    SessionPlayback= sessionIDs.last();



    /// define the 30k continuous acquisition, no filter, of the data across all 32 channels
    cbPKT_CHANINFO chan_info;

    for (int i = 0; i < 40 ; i++){
        //get current channel configuration
        res = cbSdkGetChannelConfig(0, i+1, &chan_info);

        //change configuration
        chan_info.smpfilter = 0; //continuous filter (none)
        chan_info.smpgroup = 0; //continuous sampling rate (30kHz)

        //set channel configuration
        res = cbSdkSetChannelConfig(0, i+1, &chan_info); //note: channels start at 1
    }

    /// Configure the trial to include both continuous and event data
    uint16_t bActive = 1; // reset the trial
    uint16_t uBegChan   = 1;
    uint32_t uBegMask   = 0;
    uint32_t uBegVal    = 0;
    uint16_t uEndChan   = 32;
    uint32_t uEndMask   = 0;
    uint32_t uEndVal    = 0;
    bool   bDouble    = false;
    bool   bAbsolute  = false;
    uint32_t uWaveforms = 0;
    uint32_t uConts     = cbSdk_CONTINUOUS_DATA_SAMPLES; // record the continuous data
    uint32_t uEvents    = cbSdk_EVENT_DATA_SAMPLES;
    uint32_t uComments  = 1000; // should we record the comments ?
    uint32_t uTrackings = 0;
    res = cbSdkSetTrialConfig(0, bActive, uBegChan, uBegMask, uBegVal, uEndChan, uEndMask, uEndVal, bDouble, uWaveforms, uConts, uEvents, uComments, uTrackings, bAbsolute);

    /// Init the data recording: look at the next session number in the data folder of the current mouse
    /// create folder that will contain the data
    QString currentSessionFolderName = DataFolder + "/mouse" + QString::number(Mouse.load()) +"/Playback/session"+ QString::number(SessionPlayback+1)+"/" ;
    /// create folder that will contain the data
    QDir dir;
    dir.mkdir(currentSessionFolderName);
    QString FileName = currentSessionFolderName + "data";

    /// Init the file.
    res = cbSdkSetFileConfig(0, FileName.toStdString().c_str(), "", true, cbFILECFG_OPT_NONE);



    ///Write a text file containing the PlaybackFramelist of the session

    QFile Currentframefile = DataFolder + "/mouse" + QString::number(Mouse.load()) +"/Playback/session"+ QString::number(SessionPlayback+1)+"/Trajectories.txt";

    if ( Currentframefile.open(QIODevice::ReadWrite) ){
        for (int k=0;k<PlaybackFrameList.count();k++){
            QTextStream stream( &Currentframefile );
            stream << PlaybackFrameList[k] << endl;
            }
        }



    /// Close the files and prepare the list

    PlaybackFrameCurrent=PlaybackFrameList[CurrentPBTrial].split(",");
    framefile.close();
    Currentframefile.close();


    /// Sleep for few seconds to allow the launch of recording dialogbox
    Sleep(1000);


}

void Gui::StopPlayback(){
    SessionActive.store(0);
    StartPlaybackButton->setEnabled(true);
    StartSessionButton->setDisabled(true);
    StartSessionButton->setText("Done");
    /// close the recording file
    res = cbSdkSetFileConfig(0, currentSessionFileName.toStdString().c_str(), "", false, cbFILECFG_OPT_NONE);
    /// stop projector
    AlpDevHalt( nDevId );
    AlpDevFree( nDevId );


}
/// Update GUI with the frequency of a preset Qt Timer
void Gui::update_displays(){

    //// update the graph
    chart->update();
    ///update the clock

    if (SessionActive.load()==1 || SessionActive.load()==3){
        clock1->update();
    }


    //// update image
    //currentParam=param;

//    if (currentParam.FrameList.count() == 0)
//    {
//        ImageLabel->setPixmap(QPixmap::fromImage(*ProjectedFrameImage));
//    }
//    else
//    {
//        ImageLabel->setPixmap(QPixmap::fromImage(currentParam.FrameList[FrameIdx.load()][0]));
//    }


    // Update the reward counter label to display the number of rewards on the GUI
    if (RewardCounter.load() != 0){
        RewardCounterLabel->setText(QString::number(RewardCounter.load())+ "(" +QString::number(RewardCounter.load()*DropSize) +" microL)");
    }
    if (TrialCounter.load() != 1){
        TrialCounterLabel->setText(QString::number(TrialCounter.load()));
    }
    if (LickCounter.load() != 0){
        LickCounterLabel->setText(QString::number(LickCounter.load()));
    }

}

/// Set free rewards condition
void Gui::rewardON_OFF(bool reward_ON){
    if(reward_ON){
        FlushButton->setChecked(false);
        FlushButton->setText("Start Flush");
        ContinuousRewardButton->setText("Stop");
        Water.store(1);
    } else {
        ContinuousRewardButton->setText("Habituation");
        Water.store(0);
    }
}

/// Set flush condition for cleaning the water line
void Gui::flushON_OFF(bool flush_ON){
    if(flush_ON){
        // release the free reward button
        ContinuousRewardButton->setChecked(false);
        ContinuousRewardButton->setText("Habituation");
        FlushButton->setText("Stop Flush");
        Water.store(2); // set the global variable
    } else {
        FlushButton->setText("Start Flush");
        Water.store(0);
    }
}

/// Set only one free reward
void Gui::oneFreeRewardON(){

    Water.store(3); // set the global variable
}

void Gui::ActivateDefineUnits(){
    if (DefineGroupsCheckBox->isChecked()==true){
        DefineGroupsButton->setEnabled(true);
        DefineGroupsButton->setText("Define groups");
        StartWaitingbutton->setDisabled(true);
        TestLatencyButton->setDisabled(true);
        StartPlaybackButton->setDisabled(true);
    }
    if (DefineGroupsCheckBox->isChecked()==false){
        DefineGroupsButton->setEnabled(false);
        StartWaitingbutton->setDisabled(false);
        StartWaitingbutton->setText("Start Waiting");
        TestLatencyButton->setEnabled(true);
        StartPlaybackButton->setEnabled(true);
    }

}

void Gui::getGroups(){
    /// From program ini file, get the data dir, the data
    QString IniFile = DataFolder + "/mouse" + QString::number(Mouse.load()) + "/Units/groups.ini";


    /// check if main parameter file exists and if yes: Is it really a file and no directory?
    QFileInfo check_inifile(IniFile);
    if (check_inifile.exists() && check_inifile.isFile()) {
        QSettings settings(IniFile, QSettings::IniFormat);
        QString AllTetrUPos = settings.value("Positive Group").toString();
        QString AllTetrUNeg = settings.value("Negative Group").toString();

        ListChanUPos.clear();
        ListChanUNeg.clear();

        for (int k=0;k<AllTetrUPos.length();k+=2){
            QString Tetr = AllTetrUPos[k];
            QString U = AllTetrUPos[k+1];
            if (Tetr.toDouble() == 1){
                ListChanUPos.append(qMakePair(7,U.toDouble()));
                ListChanUPos.append(qMakePair(8,U.toDouble()));
                ListChanUPos.append(qMakePair(9,U.toDouble()));
                ListChanUPos.append(qMakePair(10,U.toDouble()));
            }
            if (Tetr.toDouble() == 2){
                ListChanUPos.append(qMakePair(1,U.toDouble()));
                ListChanUPos.append(qMakePair(2,U.toDouble()));
                ListChanUPos.append(qMakePair(13,U.toDouble()));
                ListChanUPos.append(qMakePair(14,U.toDouble()));
            }
            if (Tetr.toDouble() == 3){
                ListChanUPos.append(qMakePair(19,U.toDouble()));
                ListChanUPos.append(qMakePair(20,U.toDouble()));
                ListChanUPos.append(qMakePair(31,U.toDouble()));
                ListChanUPos.append(qMakePair(32,U.toDouble()));
            }
            if (Tetr.toDouble() == 4){
                ListChanUPos.append(qMakePair(23,U.toDouble()));
                ListChanUPos.append(qMakePair(24,U.toDouble()));
                ListChanUPos.append(qMakePair(25,U.toDouble()));
                ListChanUPos.append(qMakePair(26,U.toDouble()));
            }
            if (Tetr.toDouble() == 5){
                ListChanUPos.append(qMakePair(4,U.toDouble()));
                ListChanUPos.append(qMakePair(6,U.toDouble()));
                ListChanUPos.append(qMakePair(11,U.toDouble()));
                ListChanUPos.append(qMakePair(12,U.toDouble()));
            }
            if (Tetr.toDouble() == 6){
                ListChanUPos.append(qMakePair(3,U.toDouble()));
                ListChanUPos.append(qMakePair(5,U.toDouble()));
                ListChanUPos.append(qMakePair(15,U.toDouble()));
                ListChanUPos.append(qMakePair(16,U.toDouble()));
            }
            if (Tetr.toDouble() == 7) {
                ListChanUPos.append(qMakePair(17,U.toDouble()));
                ListChanUPos.append(qMakePair(18,U.toDouble()));
                ListChanUPos.append(qMakePair(27,U.toDouble()));
                ListChanUPos.append(qMakePair(29,U.toDouble()));
            }
            if (Tetr.toDouble() == 8){
                ListChanUPos.append(qMakePair(21,U.toDouble()));
                ListChanUPos.append(qMakePair(22,U.toDouble()));
                ListChanUPos.append(qMakePair(28,U.toDouble()));
                ListChanUPos.append(qMakePair(30,U.toDouble()));
            }
        }

        for (int k=0;k<AllTetrUNeg.length();k+=2){
            QString Tetr = AllTetrUNeg[k];
            QString U = AllTetrUNeg[k+1];
            if (Tetr.toDouble() == 1){
                ListChanUNeg.append(qMakePair(7,U.toDouble()));
                ListChanUNeg.append(qMakePair(8,U.toDouble()));
                ListChanUNeg.append(qMakePair(9,U.toDouble()));
                ListChanUNeg.append(qMakePair(10,U.toDouble()));
            }
            if (Tetr.toDouble() == 2){
                ListChanUNeg.append(qMakePair(1,U.toDouble()));
                ListChanUNeg.append(qMakePair(2,U.toDouble()));
                ListChanUNeg.append(qMakePair(13,U.toDouble()));
                ListChanUNeg.append(qMakePair(14,U.toDouble()));
            }
            if (Tetr.toDouble() == 3){
                ListChanUNeg.append(qMakePair(19,U.toDouble()));
                ListChanUNeg.append(qMakePair(20,U.toDouble()));
                ListChanUNeg.append(qMakePair(31,U.toDouble()));
                ListChanUNeg.append(qMakePair(32,U.toDouble()));
            }
            if (Tetr.toDouble() == 4){
                ListChanUNeg.append(qMakePair(23,U.toDouble()));
                ListChanUNeg.append(qMakePair(24,U.toDouble()));
                ListChanUNeg.append(qMakePair(25,U.toDouble()));
                ListChanUNeg.append(qMakePair(26,U.toDouble()));
            }
            if (Tetr.toDouble() == 5){
                ListChanUNeg.append(qMakePair(4,U.toDouble()));
                ListChanUNeg.append(qMakePair(6,U.toDouble()));
                ListChanUNeg.append(qMakePair(11,U.toDouble()));
                ListChanUNeg.append(qMakePair(12,U.toDouble()));
            }
            if (Tetr.toDouble() == 6){
                ListChanUNeg.append(qMakePair(3,U.toDouble()));
                ListChanUNeg.append(qMakePair(5,U.toDouble()));
                ListChanUNeg.append(qMakePair(15,U.toDouble()));
                ListChanUNeg.append(qMakePair(16,U.toDouble()));
            }
            if (Tetr.toDouble() == 7) {
                ListChanUNeg.append(qMakePair(17,U.toDouble()));
                ListChanUNeg.append(qMakePair(18,U.toDouble()));
                ListChanUNeg.append(qMakePair(27,U.toDouble()));
                ListChanUNeg.append(qMakePair(29,U.toDouble()));
            }
            if (Tetr.toDouble() == 8){
                ListChanUNeg.append(qMakePair(21,U.toDouble()));
                ListChanUNeg.append(qMakePair(22,U.toDouble()));
                ListChanUNeg.append(qMakePair(28,U.toDouble()));
                ListChanUNeg.append(qMakePair(30,U.toDouble()));
            }

    }
    }
    else{
        ListChanUPos.clear();
        ListChanUNeg.clear();
    }

}

/// Launch a python PyQT GUI to generate and align the stimuli
void Gui::launch_generator(bool generator_ON)
{
    if (generator_ON){


        generatorButton->setText("Close generator");


        QString  command("C:/Users/User/Anaconda2/Scripts/spyder.exe");
        QStringList params = QStringList() << DataFolder+"/GenAlignStimuliHenri.pyw";

        generator = new QProcess();

        generator->start(command,params);
    }else
    {
        generatorButton->setText("Launch generator");
        generator->close();
    }
}

/// Lauch live acquisition from CCD camera
void Gui::launch_ccd_camera(bool liveON){
    if (liveON){
        GrabReferenceImage.store(0);
        ccd_cameraButton->setText("Stop Live");
        worker->abort();
        thread->wait(); // If the thread is not running, this will immediately return.
        worker->requestWork();
    }else{
        GrabReferenceImage.store(0);
        ccd_cameraButton->setText("Go Live");
        worker->abort();
    }
}

void Gui::grab_image(bool) {
    GetLastSession();
    refImageFolder = DataFolder + "/mouse" + QString::number(Mouse.load()) + "/reference_images/";
    QDir dir(refImageFolder);
    qDebug() << refImageFolder;
    if (!dir.exists()){
        qDebug() << "directory  doesn't exists";
        dir.mkdir(refImageFolder);
    }
    refImageFolder = refImageFolder + "img_ref_S"+QString::number(Session.load()+1) +".tiff";
    GrabReferenceImage.store(1);
}

void Gui::ActivateRandomized(){
    if(RandomizedCheckBox->isChecked()==true){
        RandomizedActive.store(1);
    }
    if(RandomizedCheckBox->isChecked()==false){
        RandomizedActive.store(0);
    }

}
